# Notes (product-roadmap inbox-notes)


### 2025-09-04 13:42:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134212.md




### 2025-09-04 13:42:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134216.md




### 2025-09-04 13:42:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134242.md




### 2025-09-04 13:42:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134243.md




### 2025-09-04 13:42:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134245.md




### 2025-09-04 13:43:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134312.md




### 2025-09-04 13:43:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134324.md




### 2025-09-04 13:43:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134325.md




### 2025-09-04 13:43:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134330.md




### 2025-09-04 13:44:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134417.md




### 2025-09-04 13:44:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134418.md




### 2025-09-04 13:44:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134420.md




### 2025-09-04 13:44:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134422.md




### 2025-09-04 13:44:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134422.md




### 2025-09-04 13:44:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134430.md




### 2025-09-04 13:44:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134432.md




### 2025-09-04 13:44:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134440.md




### 2025-09-04 13:44:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134448.md




### 2025-09-04 13:44:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134449.md




### 2025-09-04 13:44:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134455.md




### 2025-09-04 13:45:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134504.md




### 2025-09-04 13:45:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134506.md




### 2025-09-04 13:45:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134512.md




### 2025-09-04 13:45:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134514.md




### 2025-09-04 13:45:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134514.md




### 2025-09-04 13:45:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134524.md




### 2025-09-04 13:45:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134526.md




### 2025-09-04 13:45:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134531.md




### 2025-09-04 13:45:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134541.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134554.md




### 2025-09-04 13:45:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134557.md




### 2025-09-04 13:46:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134602.md




### 2025-09-04 13:46:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134606.md




### 2025-09-04 13:46:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134619.md




### 2025-09-04 13:46:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134623.md




### 2025-09-04 13:46:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134631.md




### 2025-09-04 13:46:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134641.md




### 2025-09-04 13:46:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134643.md




### 2025-09-04 13:46:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134644.md




### 2025-09-04 13:46:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134654.md




### 2025-09-04 13:47:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134704.md




### 2025-09-04 13:47:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134721.md




### 2025-09-04 13:47:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134751.md




### 2025-09-04 13:47:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134752.md




### 2025-09-04 13:47:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134754.md




### 2025-09-04 13:47:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134759.md




### 2025-09-04 13:47:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134759.md




### 2025-09-04 13:48:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134812.md




### 2025-09-04 13:48:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134850.md




### 2025-09-04 13:48:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134852.md




### 2025-09-04 13:49:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134900.md




### 2025-09-04 13:49:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134903.md




### 2025-09-04 13:49:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134928.md




### 2025-09-04 13:49:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134939.md




### 2025-09-04 13:49:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134946.md




### 2025-09-04 13:50:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135026.md




### 2025-09-04 13:50:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135027.md




### 2025-09-04 13:50:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135042.md




### 2025-09-04 13:51:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135110.md




### 2025-09-04 13:51:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135114.md




### 2025-09-04 13:51:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135132.md




### 2025-09-04 13:51:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135144.md




### 2025-09-04 13:51:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135154.md




### 2025-09-04 13:52:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135202.md




### 2025-09-04 13:52:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135206.md




### 2025-09-04 13:52:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135219.md




### 2025-09-04 13:52:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135220.md




### 2025-09-04 13:53:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135316.md




### 2025-09-04 13:53:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135329.md




### 2025-09-04 13:53:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135331.md




### 2025-09-04 13:53:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135332.md




### 2025-09-04 13:53:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135338.md




### 2025-09-04 13:53:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135338.md




### 2025-09-04 13:53:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135345.md




### 2025-09-04 13:53:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135353.md




### 2025-09-04 13:54:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135412.md




### 2025-09-04 13:54:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135448.md




### 2025-09-04 13:54:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135455.md




### 2025-09-04 13:54:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135457.md




### 2025-09-04 13:54:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135459.md




### 2025-09-04 13:55:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135502.md




### 2025-09-04 13:55:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135505.md




### 2025-09-04 13:55:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135510.md




### 2025-09-04 13:55:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135528.md




### 2025-09-04 13:55:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135541.md




### 2025-09-04 13:55:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135551.md




### 2025-09-04 13:56:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135603.md




### 2025-09-04 13:56:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135612.md




### 2025-09-04 13:56:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135638.md




### 2025-09-04 13:56:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135651.md




### 2025-09-04 13:57:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135701.md




### 2025-09-04 13:57:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135708.md




### 2025-09-04 13:57:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135716.md




### 2025-09-04 13:57:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135716.md




### 2025-09-04 13:57:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135718.md




### 2025-09-04 13:57:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135732.md




### 2025-09-04 13:57:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135741.md




### 2025-09-04 13:57:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135752.md




### 2025-09-04 13:57:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135759.md




### 2025-09-04 13:58:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135804.md




### 2025-09-04 13:58:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135810.md




### 2025-09-04 13:58:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135814.md




### 2025-09-04 13:58:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135843.md




### 2025-09-04 13:58:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135850.md




### 2025-09-04 13:59:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135911.md




### 2025-09-04 13:59:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135917.md




### 2025-09-04 13:59:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135922.md




### 2025-09-04 13:59:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135923.md




### 2025-09-04 13:59:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135937.md




### 2025-09-04 13:59:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135944.md




### 2025-09-04 13:59:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135957.md




### 2025-09-04 14:00:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140021.md




### 2025-09-04 14:00:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140024.md




### 2025-09-04 14:00:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140028.md




### 2025-09-04 14:00:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140050.md




### 2025-09-04 14:00:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140056.md

