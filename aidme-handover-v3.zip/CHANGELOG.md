## v5.6.1
- Mest komplette versjon hittil

## v5.6.2
- Hotfix STT mobil + små UI-forbedringer

## v5.6.3
- Ny STT-fiks og UI-forbedringer
