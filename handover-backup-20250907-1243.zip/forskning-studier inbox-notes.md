# Notes (forskning-studier inbox-notes)


### 2025-09-04 13:42:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134217.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134318.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134344.md




### 2025-09-04 13:44:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134418.md




### 2025-09-04 13:44:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134430.md




### 2025-09-04 13:44:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134448.md




### 2025-09-04 13:45:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134510.md




### 2025-09-04 13:45:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134548.md




### 2025-09-04 13:45:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134556.md




### 2025-09-04 13:45:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134559.md




### 2025-09-04 13:46:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134612.md




### 2025-09-04 13:46:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134617.md




### 2025-09-04 13:46:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134632.md




### 2025-09-04 13:47:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134700.md




### 2025-09-04 13:47:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134721.md




### 2025-09-04 13:48:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134815.md




### 2025-09-04 13:49:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134930.md




### 2025-09-04 13:49:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134954.md




### 2025-09-04 13:50:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135013.md




### 2025-09-04 13:50:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135018.md




### 2025-09-04 13:50:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135033.md




### 2025-09-04 13:50:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135039.md




### 2025-09-04 13:50:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135042.md




### 2025-09-04 13:50:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135045.md




### 2025-09-04 13:51:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135118.md




### 2025-09-04 13:51:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135128.md




### 2025-09-04 13:51:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135139.md




### 2025-09-04 13:51:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135144.md




### 2025-09-04 13:51:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135150.md




### 2025-09-04 13:52:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135222.md




### 2025-09-04 13:52:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135234.md




### 2025-09-04 13:52:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135248.md




### 2025-09-04 13:53:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135330.md




### 2025-09-04 13:54:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135401.md




### 2025-09-04 13:54:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135425.md




### 2025-09-04 13:54:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135430.md




### 2025-09-04 13:54:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135435.md




### 2025-09-04 13:54:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135436.md




### 2025-09-04 13:54:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135447.md




### 2025-09-04 13:54:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135453.md




### 2025-09-04 13:54:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135454.md




### 2025-09-04 13:55:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135503.md




### 2025-09-04 13:55:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135538.md




### 2025-09-04 13:55:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135539.md




### 2025-09-04 13:55:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135554.md




### 2025-09-04 13:56:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135606.md




### 2025-09-04 13:56:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135625.md




### 2025-09-04 13:56:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135636.md




### 2025-09-04 13:56:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135643.md




### 2025-09-04 13:57:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135703.md




### 2025-09-04 13:57:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135706.md




### 2025-09-04 13:57:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135722.md




### 2025-09-04 13:57:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135730.md




### 2025-09-04 13:57:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135742.md




### 2025-09-04 13:57:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135745.md




### 2025-09-04 13:58:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135822.md




### 2025-09-04 13:59:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135901.md




### 2025-09-04 13:59:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135918.md




### 2025-09-04 13:59:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135926.md




### 2025-09-04 13:59:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135926.md




### 2025-09-04 13:59:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135934.md




### 2025-09-04 13:59:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135936.md




### 2025-09-04 13:59:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135941.md




### 2025-09-04 13:59:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135945.md




### 2025-09-04 14:00:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140012.md




### 2025-09-04 14:00:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140038.md




### 2025-09-04 14:00:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140038.md




### 2025-09-04 14:00:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140040.md




### 2025-09-04 14:00:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140048.md

