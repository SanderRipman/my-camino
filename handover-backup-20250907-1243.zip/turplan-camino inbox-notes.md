# Notes (turplan-camino inbox-notes)


### 2025-09-04 13:42:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134209.md




### 2025-09-04 13:42:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134210.md




### 2025-09-04 13:42:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134210.md




### 2025-09-04 13:42:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134210.md




### 2025-09-04 13:42:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134210.md




### 2025-09-04 13:42:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134210.md




### 2025-09-04 13:42:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134211.md




### 2025-09-04 13:42:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134212.md




### 2025-09-04 13:42:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134213.md




### 2025-09-04 13:42:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134213.md




### 2025-09-04 13:42:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134213.md




### 2025-09-04 13:42:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134213.md




### 2025-09-04 13:42:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134215.md




### 2025-09-04 13:42:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134215.md




### 2025-09-04 13:42:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134216.md




### 2025-09-04 13:42:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134216.md




### 2025-09-04 13:42:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134216.md




### 2025-09-04 13:42:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134218.md




### 2025-09-04 13:42:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134218.md




### 2025-09-04 13:42:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134218.md




### 2025-09-04 13:42:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134218.md




### 2025-09-04 13:42:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134219.md




### 2025-09-04 13:42:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134219.md




### 2025-09-04 13:42:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134220.md




### 2025-09-04 13:42:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134220.md




### 2025-09-04 13:42:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134220.md




### 2025-09-04 13:42:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134221.md




### 2025-09-04 13:42:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134222.md




### 2025-09-04 13:42:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134222.md




### 2025-09-04 13:42:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134223.md




### 2025-09-04 13:42:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134223.md




### 2025-09-04 13:42:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134223.md




### 2025-09-04 13:42:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134223.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134224.md




### 2025-09-04 13:42:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134225.md




### 2025-09-04 13:42:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134225.md




### 2025-09-04 13:42:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134226.md




### 2025-09-04 13:42:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134226.md




### 2025-09-04 13:42:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134227.md




### 2025-09-04 13:42:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134227.md




### 2025-09-04 13:42:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134227.md




### 2025-09-04 13:42:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134227.md




### 2025-09-04 13:42:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134228.md




### 2025-09-04 13:42:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134228.md




### 2025-09-04 13:42:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134229.md




### 2025-09-04 13:42:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134229.md




### 2025-09-04 13:42:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134230.md




### 2025-09-04 13:42:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134231.md




### 2025-09-04 13:42:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134232.md




### 2025-09-04 13:42:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134233.md




### 2025-09-04 13:42:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134234.md




### 2025-09-04 13:42:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134235.md




### 2025-09-04 13:42:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134235.md




### 2025-09-04 13:42:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134237.md




### 2025-09-04 13:42:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134237.md




### 2025-09-04 13:42:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134238.md




### 2025-09-04 13:42:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134238.md




### 2025-09-04 13:42:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134238.md




### 2025-09-04 13:42:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134239.md




### 2025-09-04 13:42:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134239.md




### 2025-09-04 13:42:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134240.md




### 2025-09-04 13:42:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134240.md




### 2025-09-04 13:42:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134240.md




### 2025-09-04 13:42:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134240.md




### 2025-09-04 13:42:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134241.md




### 2025-09-04 13:42:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134241.md




### 2025-09-04 13:42:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134242.md




### 2025-09-04 13:42:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134244.md




### 2025-09-04 13:42:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134244.md




### 2025-09-04 13:42:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134244.md




### 2025-09-04 13:42:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134245.md




### 2025-09-04 13:42:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134245.md




### 2025-09-04 13:42:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134246.md




### 2025-09-04 13:42:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134247.md




### 2025-09-04 13:42:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134247.md




### 2025-09-04 13:42:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134248.md




### 2025-09-04 13:42:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134249.md




### 2025-09-04 13:42:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134249.md




### 2025-09-04 13:42:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134250.md




### 2025-09-04 13:42:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134252.md




### 2025-09-04 13:42:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134252.md




### 2025-09-04 13:42:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134254.md




### 2025-09-04 13:42:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134256.md




### 2025-09-04 13:42:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134256.md




### 2025-09-04 13:42:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134256.md




### 2025-09-04 13:42:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134257.md




### 2025-09-04 13:42:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134257.md




### 2025-09-04 13:42:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134258.md




### 2025-09-04 13:42:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134258.md




### 2025-09-04 13:42:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134259.md




### 2025-09-04 13:42:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134259.md




### 2025-09-04 13:43:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134300.md




### 2025-09-04 13:43:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134300.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134301.md




### 2025-09-04 13:43:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134302.md




### 2025-09-04 13:43:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134302.md




### 2025-09-04 13:43:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134303.md




### 2025-09-04 13:43:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134304.md




### 2025-09-04 13:43:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134304.md




### 2025-09-04 13:43:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134305.md




### 2025-09-04 13:43:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134306.md




### 2025-09-04 13:43:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134306.md




### 2025-09-04 13:43:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134306.md




### 2025-09-04 13:43:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134307.md




### 2025-09-04 13:43:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134308.md




### 2025-09-04 13:43:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134308.md




### 2025-09-04 13:43:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134308.md




### 2025-09-04 13:43:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134310.md




### 2025-09-04 13:43:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134311.md




### 2025-09-04 13:43:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134312.md




### 2025-09-04 13:43:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134312.md




### 2025-09-04 13:43:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134312.md




### 2025-09-04 13:43:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134312.md




### 2025-09-04 13:43:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134313.md




### 2025-09-04 13:43:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134313.md




### 2025-09-04 13:43:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134315.md




### 2025-09-04 13:43:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134316.md




### 2025-09-04 13:43:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134318.md




### 2025-09-04 13:43:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134318.md




### 2025-09-04 13:43:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134319.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134320.md




### 2025-09-04 13:43:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134321.md




### 2025-09-04 13:43:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134321.md




### 2025-09-04 13:43:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134321.md




### 2025-09-04 13:43:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134321.md




### 2025-09-04 13:43:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134322.md




### 2025-09-04 13:43:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134322.md




### 2025-09-04 13:43:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134323.md




### 2025-09-04 13:43:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134324.md




### 2025-09-04 13:43:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134324.md




### 2025-09-04 13:43:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134324.md




### 2025-09-04 13:43:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134325.md




### 2025-09-04 13:43:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134325.md




### 2025-09-04 13:43:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134325.md




### 2025-09-04 13:43:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134326.md




### 2025-09-04 13:43:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134326.md




### 2025-09-04 13:43:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134326.md




### 2025-09-04 13:43:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134326.md




### 2025-09-04 13:43:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134326.md




### 2025-09-04 13:43:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134327.md




### 2025-09-04 13:43:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134328.md




### 2025-09-04 13:43:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134329.md




### 2025-09-04 13:43:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134329.md




### 2025-09-04 13:43:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134331.md




### 2025-09-04 13:43:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134332.md




### 2025-09-04 13:43:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134332.md




### 2025-09-04 13:43:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134333.md




### 2025-09-04 13:43:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134334.md




### 2025-09-04 13:43:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134334.md




### 2025-09-04 13:43:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134336.md




### 2025-09-04 13:43:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134336.md




### 2025-09-04 13:43:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134336.md




### 2025-09-04 13:43:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134338.md




### 2025-09-04 13:43:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134338.md




### 2025-09-04 13:43:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134339.md




### 2025-09-04 13:43:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134339.md




### 2025-09-04 13:43:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134339.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134340.md




### 2025-09-04 13:43:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134341.md




### 2025-09-04 13:43:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134341.md




### 2025-09-04 13:43:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134341.md




### 2025-09-04 13:43:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134342.md




### 2025-09-04 13:43:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134342.md




### 2025-09-04 13:43:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134342.md




### 2025-09-04 13:43:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134343.md




### 2025-09-04 13:43:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134344.md




### 2025-09-04 13:43:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134344.md




### 2025-09-04 13:43:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134346.md




### 2025-09-04 13:43:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134348.md




### 2025-09-04 13:43:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134348.md




### 2025-09-04 13:43:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134349.md




### 2025-09-04 13:43:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134349.md




### 2025-09-04 13:43:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134350.md




### 2025-09-04 13:43:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134352.md




### 2025-09-04 13:43:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134353.md




### 2025-09-04 13:43:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134353.md




### 2025-09-04 13:43:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134354.md




### 2025-09-04 13:43:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134354.md




### 2025-09-04 13:43:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134354.md




### 2025-09-04 13:43:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134357.md




### 2025-09-04 13:43:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134357.md




### 2025-09-04 13:43:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134357.md




### 2025-09-04 13:44:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134401.md




### 2025-09-04 13:44:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134401.md




### 2025-09-04 13:44:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134402.md




### 2025-09-04 13:44:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134403.md




### 2025-09-04 13:44:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134403.md




### 2025-09-04 13:44:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134403.md




### 2025-09-04 13:44:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134404.md




### 2025-09-04 13:44:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134404.md




### 2025-09-04 13:44:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134404.md




### 2025-09-04 13:44:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134404.md




### 2025-09-04 13:44:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134405.md




### 2025-09-04 13:44:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134405.md




### 2025-09-04 13:44:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134405.md




### 2025-09-04 13:44:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134405.md




### 2025-09-04 13:44:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134405.md




### 2025-09-04 13:44:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134406.md




### 2025-09-04 13:44:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134408.md




### 2025-09-04 13:44:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134408.md




### 2025-09-04 13:44:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134408.md




### 2025-09-04 13:44:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134408.md




### 2025-09-04 13:44:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134409.md




### 2025-09-04 13:44:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134409.md




### 2025-09-04 13:44:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134409.md




### 2025-09-04 13:44:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134409.md




### 2025-09-04 13:44:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134409.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134410.md




### 2025-09-04 13:44:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134411.md




### 2025-09-04 13:44:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134411.md




### 2025-09-04 13:44:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134412.md




### 2025-09-04 13:44:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134413.md




### 2025-09-04 13:44:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134413.md




### 2025-09-04 13:44:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134413.md




### 2025-09-04 13:44:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134413.md




### 2025-09-04 13:44:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134414.md




### 2025-09-04 13:44:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134414.md




### 2025-09-04 13:44:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134415.md




### 2025-09-04 13:44:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134416.md




### 2025-09-04 13:44:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134416.md




### 2025-09-04 13:44:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134416.md




### 2025-09-04 13:44:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134416.md




### 2025-09-04 13:44:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134418.md




### 2025-09-04 13:44:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134423.md




### 2025-09-04 13:44:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134424.md




### 2025-09-04 13:44:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134424.md




### 2025-09-04 13:44:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134424.md




### 2025-09-04 13:44:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134425.md




### 2025-09-04 13:44:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134425.md




### 2025-09-04 13:44:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134425.md




### 2025-09-04 13:44:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134426.md




### 2025-09-04 13:44:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134426.md




### 2025-09-04 13:44:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134426.md




### 2025-09-04 13:44:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134426.md




### 2025-09-04 13:44:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134427.md




### 2025-09-04 13:44:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134427.md




### 2025-09-04 13:44:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134427.md




### 2025-09-04 13:44:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134427.md




### 2025-09-04 13:44:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134428.md




### 2025-09-04 13:44:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134428.md




### 2025-09-04 13:44:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134428.md




### 2025-09-04 13:44:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134428.md




### 2025-09-04 13:44:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134429.md




### 2025-09-04 13:44:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134429.md




### 2025-09-04 13:44:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134430.md




### 2025-09-04 13:44:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134430.md




### 2025-09-04 13:44:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134430.md




### 2025-09-04 13:44:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134431.md




### 2025-09-04 13:44:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134431.md




### 2025-09-04 13:44:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134432.md




### 2025-09-04 13:44:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134433.md




### 2025-09-04 13:44:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134433.md




### 2025-09-04 13:44:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134434.md




### 2025-09-04 13:44:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134434.md




### 2025-09-04 13:44:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134434.md




### 2025-09-04 13:44:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134434.md




### 2025-09-04 13:44:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134434.md




### 2025-09-04 13:44:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134435.md




### 2025-09-04 13:44:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134435.md




### 2025-09-04 13:44:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134436.md




### 2025-09-04 13:44:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134436.md




### 2025-09-04 13:44:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134437.md




### 2025-09-04 13:44:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134438.md




### 2025-09-04 13:44:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134439.md




### 2025-09-04 13:44:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134440.md




### 2025-09-04 13:44:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134441.md




### 2025-09-04 13:44:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134441.md




### 2025-09-04 13:44:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134441.md




### 2025-09-04 13:44:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134442.md




### 2025-09-04 13:44:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134442.md




### 2025-09-04 13:44:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134442.md




### 2025-09-04 13:44:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134443.md




### 2025-09-04 13:44:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134443.md




### 2025-09-04 13:44:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134444.md




### 2025-09-04 13:44:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134444.md




### 2025-09-04 13:44:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134445.md




### 2025-09-04 13:44:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134445.md




### 2025-09-04 13:44:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134446.md




### 2025-09-04 13:44:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134446.md




### 2025-09-04 13:44:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134447.md




### 2025-09-04 13:44:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134447.md




### 2025-09-04 13:44:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134447.md




### 2025-09-04 13:44:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134448.md




### 2025-09-04 13:44:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134448.md




### 2025-09-04 13:44:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134449.md




### 2025-09-04 13:44:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134449.md




### 2025-09-04 13:44:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134449.md




### 2025-09-04 13:44:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134450.md




### 2025-09-04 13:44:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134450.md




### 2025-09-04 13:44:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134451.md




### 2025-09-04 13:44:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134452.md




### 2025-09-04 13:44:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134452.md




### 2025-09-04 13:44:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134453.md




### 2025-09-04 13:44:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134454.md




### 2025-09-04 13:44:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134455.md




### 2025-09-04 13:44:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134455.md




### 2025-09-04 13:44:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134456.md




### 2025-09-04 13:44:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134457.md




### 2025-09-04 13:44:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134457.md




### 2025-09-04 13:44:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134457.md




### 2025-09-04 13:44:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134457.md




### 2025-09-04 13:44:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134458.md




### 2025-09-04 13:44:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134459.md




### 2025-09-04 13:44:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134459.md




### 2025-09-04 13:45:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134501.md




### 2025-09-04 13:45:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134502.md




### 2025-09-04 13:45:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134503.md




### 2025-09-04 13:45:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134504.md




### 2025-09-04 13:45:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134504.md




### 2025-09-04 13:45:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134504.md




### 2025-09-04 13:45:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134505.md




### 2025-09-04 13:45:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134505.md




### 2025-09-04 13:45:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134506.md




### 2025-09-04 13:45:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134507.md




### 2025-09-04 13:45:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134507.md




### 2025-09-04 13:45:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134507.md




### 2025-09-04 13:45:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134508.md




### 2025-09-04 13:45:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134509.md




### 2025-09-04 13:45:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134510.md




### 2025-09-04 13:45:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134510.md




### 2025-09-04 13:45:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134510.md




### 2025-09-04 13:45:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134511.md




### 2025-09-04 13:45:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134511.md




### 2025-09-04 13:45:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134512.md




### 2025-09-04 13:45:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134514.md




### 2025-09-04 13:45:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134516.md




### 2025-09-04 13:45:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134516.md




### 2025-09-04 13:45:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134516.md




### 2025-09-04 13:45:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134516.md




### 2025-09-04 13:45:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134516.md




### 2025-09-04 13:45:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134517.md




### 2025-09-04 13:45:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134517.md




### 2025-09-04 13:45:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134517.md




### 2025-09-04 13:45:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134517.md




### 2025-09-04 13:45:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134518.md




### 2025-09-04 13:45:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134519.md




### 2025-09-04 13:45:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134519.md




### 2025-09-04 13:45:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134520.md




### 2025-09-04 13:45:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134521.md




### 2025-09-04 13:45:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134521.md




### 2025-09-04 13:45:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134522.md




### 2025-09-04 13:45:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134522.md




### 2025-09-04 13:45:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134523.md




### 2025-09-04 13:45:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134524.md




### 2025-09-04 13:45:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134526.md




### 2025-09-04 13:45:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134527.md




### 2025-09-04 13:45:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134527.md




### 2025-09-04 13:45:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134530.md




### 2025-09-04 13:45:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134531.md




### 2025-09-04 13:45:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134531.md




### 2025-09-04 13:45:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134532.md




### 2025-09-04 13:45:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134533.md




### 2025-09-04 13:45:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134534.md




### 2025-09-04 13:45:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134534.md




### 2025-09-04 13:45:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134535.md




### 2025-09-04 13:45:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134535.md




### 2025-09-04 13:45:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134535.md




### 2025-09-04 13:45:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134535.md




### 2025-09-04 13:45:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134535.md




### 2025-09-04 13:45:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134536.md




### 2025-09-04 13:45:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134536.md




### 2025-09-04 13:45:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134538.md




### 2025-09-04 13:45:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134538.md




### 2025-09-04 13:45:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134538.md




### 2025-09-04 13:45:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134539.md




### 2025-09-04 13:45:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134539.md




### 2025-09-04 13:45:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134539.md




### 2025-09-04 13:45:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134540.md




### 2025-09-04 13:45:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134540.md




### 2025-09-04 13:45:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134541.md




### 2025-09-04 13:45:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134541.md




### 2025-09-04 13:45:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134541.md




### 2025-09-04 13:45:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134542.md




### 2025-09-04 13:45:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134542.md




### 2025-09-04 13:45:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134542.md




### 2025-09-04 13:45:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134542.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134543.md




### 2025-09-04 13:45:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134544.md




### 2025-09-04 13:45:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134544.md




### 2025-09-04 13:45:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134544.md




### 2025-09-04 13:45:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134546.md




### 2025-09-04 13:45:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134546.md




### 2025-09-04 13:45:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134546.md




### 2025-09-04 13:45:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134546.md




### 2025-09-04 13:45:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134547.md




### 2025-09-04 13:45:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134547.md




### 2025-09-04 13:45:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134547.md




### 2025-09-04 13:45:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134549.md




### 2025-09-04 13:45:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134550.md




### 2025-09-04 13:45:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134550.md




### 2025-09-04 13:45:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134550.md




### 2025-09-04 13:45:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134551.md




### 2025-09-04 13:45:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134551.md




### 2025-09-04 13:45:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134552.md




### 2025-09-04 13:45:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134552.md




### 2025-09-04 13:45:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134553.md




### 2025-09-04 13:45:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134553.md




### 2025-09-04 13:45:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134553.md




### 2025-09-04 13:45:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134553.md




### 2025-09-04 13:45:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134554.md




### 2025-09-04 13:45:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134555.md




### 2025-09-04 13:45:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134556.md




### 2025-09-04 13:45:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134557.md




### 2025-09-04 13:45:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134557.md




### 2025-09-04 13:45:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134557.md




### 2025-09-04 13:45:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134559.md




### 2025-09-04 13:45:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134559.md




### 2025-09-04 13:45:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134559.md




### 2025-09-04 13:45:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134559.md




### 2025-09-04 13:46:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134600.md




### 2025-09-04 13:46:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134600.md




### 2025-09-04 13:46:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134601.md




### 2025-09-04 13:46:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134601.md




### 2025-09-04 13:46:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134601.md




### 2025-09-04 13:46:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134601.md




### 2025-09-04 13:46:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134602.md




### 2025-09-04 13:46:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134604.md




### 2025-09-04 13:46:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134604.md




### 2025-09-04 13:46:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134605.md




### 2025-09-04 13:46:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134605.md




### 2025-09-04 13:46:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134605.md




### 2025-09-04 13:46:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134606.md




### 2025-09-04 13:46:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134606.md




### 2025-09-04 13:46:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134608.md




### 2025-09-04 13:46:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134608.md




### 2025-09-04 13:46:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134608.md




### 2025-09-04 13:46:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134609.md




### 2025-09-04 13:46:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134609.md




### 2025-09-04 13:46:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134610.md




### 2025-09-04 13:46:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134610.md




### 2025-09-04 13:46:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134611.md




### 2025-09-04 13:46:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134611.md




### 2025-09-04 13:46:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134612.md




### 2025-09-04 13:46:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134612.md




### 2025-09-04 13:46:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134612.md




### 2025-09-04 13:46:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134613.md




### 2025-09-04 13:46:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134614.md




### 2025-09-04 13:46:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134614.md




### 2025-09-04 13:46:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134615.md




### 2025-09-04 13:46:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134615.md




### 2025-09-04 13:46:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134615.md




### 2025-09-04 13:46:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134616.md




### 2025-09-04 13:46:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134616.md




### 2025-09-04 13:46:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134616.md




### 2025-09-04 13:46:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134619.md




### 2025-09-04 13:46:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134621.md




### 2025-09-04 13:46:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134621.md




### 2025-09-04 13:46:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134622.md




### 2025-09-04 13:46:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134622.md




### 2025-09-04 13:46:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134622.md




### 2025-09-04 13:46:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134624.md




### 2025-09-04 13:46:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134625.md




### 2025-09-04 13:46:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134626.md




### 2025-09-04 13:46:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134626.md




### 2025-09-04 13:46:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134627.md




### 2025-09-04 13:46:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134628.md




### 2025-09-04 13:46:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134628.md




### 2025-09-04 13:46:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134630.md




### 2025-09-04 13:46:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134631.md




### 2025-09-04 13:46:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134633.md




### 2025-09-04 13:46:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134633.md




### 2025-09-04 13:46:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134633.md




### 2025-09-04 13:46:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134634.md




### 2025-09-04 13:46:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134634.md




### 2025-09-04 13:46:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134634.md




### 2025-09-04 13:46:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134635.md




### 2025-09-04 13:46:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134635.md




### 2025-09-04 13:46:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134636.md




### 2025-09-04 13:46:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134636.md




### 2025-09-04 13:46:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134636.md




### 2025-09-04 13:46:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134637.md




### 2025-09-04 13:46:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134638.md




### 2025-09-04 13:46:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134638.md




### 2025-09-04 13:46:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134639.md




### 2025-09-04 13:46:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134640.md




### 2025-09-04 13:46:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134640.md




### 2025-09-04 13:46:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134642.md




### 2025-09-04 13:46:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134643.md




### 2025-09-04 13:46:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134643.md




### 2025-09-04 13:46:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134643.md




### 2025-09-04 13:46:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134644.md




### 2025-09-04 13:46:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134646.md




### 2025-09-04 13:46:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134648.md




### 2025-09-04 13:46:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134648.md




### 2025-09-04 13:46:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134649.md




### 2025-09-04 13:46:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134649.md




### 2025-09-04 13:46:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134649.md




### 2025-09-04 13:46:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134650.md




### 2025-09-04 13:46:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134651.md




### 2025-09-04 13:46:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134653.md




### 2025-09-04 13:46:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134653.md




### 2025-09-04 13:46:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134654.md




### 2025-09-04 13:46:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134655.md




### 2025-09-04 13:46:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134656.md




### 2025-09-04 13:46:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134658.md




### 2025-09-04 13:46:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134659.md




### 2025-09-04 13:47:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134700.md




### 2025-09-04 13:47:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134703.md




### 2025-09-04 13:47:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134703.md




### 2025-09-04 13:47:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134704.md




### 2025-09-04 13:47:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134705.md




### 2025-09-04 13:47:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134706.md




### 2025-09-04 13:47:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134708.md




### 2025-09-04 13:47:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134708.md




### 2025-09-04 13:47:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134709.md




### 2025-09-04 13:47:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134709.md




### 2025-09-04 13:47:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134709.md




### 2025-09-04 13:47:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134711.md




### 2025-09-04 13:47:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134711.md




### 2025-09-04 13:47:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134712.md




### 2025-09-04 13:47:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134712.md




### 2025-09-04 13:47:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134713.md




### 2025-09-04 13:47:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134714.md




### 2025-09-04 13:47:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134715.md




### 2025-09-04 13:47:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134715.md




### 2025-09-04 13:47:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134716.md




### 2025-09-04 13:47:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134717.md




### 2025-09-04 13:47:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134718.md




### 2025-09-04 13:47:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134720.md




### 2025-09-04 13:47:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134721.md




### 2025-09-04 13:47:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134724.md




### 2025-09-04 13:47:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134724.md




### 2025-09-04 13:47:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134725.md




### 2025-09-04 13:47:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134725.md




### 2025-09-04 13:47:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134725.md




### 2025-09-04 13:47:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134725.md




### 2025-09-04 13:47:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134725.md




### 2025-09-04 13:47:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134726.md




### 2025-09-04 13:47:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134726.md




### 2025-09-04 13:47:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134727.md




### 2025-09-04 13:47:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134728.md




### 2025-09-04 13:47:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134729.md




### 2025-09-04 13:47:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134731.md




### 2025-09-04 13:47:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134732.md




### 2025-09-04 13:47:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134733.md




### 2025-09-04 13:47:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134733.md




### 2025-09-04 13:47:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134735.md




### 2025-09-04 13:47:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134736.md




### 2025-09-04 13:47:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134736.md




### 2025-09-04 13:47:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134736.md




### 2025-09-04 13:47:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134736.md




### 2025-09-04 13:47:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134737.md




### 2025-09-04 13:47:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134737.md




### 2025-09-04 13:47:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134738.md




### 2025-09-04 13:47:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134739.md




### 2025-09-04 13:47:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134740.md




### 2025-09-04 13:47:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134741.md




### 2025-09-04 13:47:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134741.md




### 2025-09-04 13:47:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134741.md




### 2025-09-04 13:47:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134742.md




### 2025-09-04 13:47:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134742.md




### 2025-09-04 13:47:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134743.md




### 2025-09-04 13:47:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134743.md




### 2025-09-04 13:47:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134744.md




### 2025-09-04 13:47:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134744.md




### 2025-09-04 13:47:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134744.md




### 2025-09-04 13:47:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134745.md




### 2025-09-04 13:47:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134745.md




### 2025-09-04 13:47:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134747.md




### 2025-09-04 13:47:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134748.md




### 2025-09-04 13:47:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134749.md




### 2025-09-04 13:47:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134749.md




### 2025-09-04 13:47:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134749.md




### 2025-09-04 13:47:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134750.md




### 2025-09-04 13:47:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134750.md




### 2025-09-04 13:47:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134753.md




### 2025-09-04 13:47:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134754.md




### 2025-09-04 13:47:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134754.md




### 2025-09-04 13:47:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134754.md




### 2025-09-04 13:47:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134755.md




### 2025-09-04 13:47:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134755.md




### 2025-09-04 13:47:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134755.md




### 2025-09-04 13:47:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134755.md




### 2025-09-04 13:47:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134756.md




### 2025-09-04 13:47:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134756.md




### 2025-09-04 13:47:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134757.md




### 2025-09-04 13:47:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134758.md




### 2025-09-04 13:48:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134802.md




### 2025-09-04 13:48:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134802.md




### 2025-09-04 13:48:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134802.md




### 2025-09-04 13:48:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134803.md




### 2025-09-04 13:48:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134804.md




### 2025-09-04 13:48:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134805.md




### 2025-09-04 13:48:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134806.md




### 2025-09-04 13:48:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134806.md




### 2025-09-04 13:48:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134806.md




### 2025-09-04 13:48:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134807.md




### 2025-09-04 13:48:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134808.md




### 2025-09-04 13:48:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134808.md




### 2025-09-04 13:48:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134809.md




### 2025-09-04 13:48:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134809.md




### 2025-09-04 13:48:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134810.md




### 2025-09-04 13:48:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134810.md




### 2025-09-04 13:48:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134811.md




### 2025-09-04 13:48:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134814.md




### 2025-09-04 13:48:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134815.md




### 2025-09-04 13:48:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134816.md




### 2025-09-04 13:48:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134816.md




### 2025-09-04 13:48:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134816.md




### 2025-09-04 13:48:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134816.md




### 2025-09-04 13:48:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134817.md




### 2025-09-04 13:48:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134817.md




### 2025-09-04 13:48:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134818.md




### 2025-09-04 13:48:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134818.md




### 2025-09-04 13:48:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134819.md




### 2025-09-04 13:48:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134820.md




### 2025-09-04 13:48:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134820.md




### 2025-09-04 13:48:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134821.md




### 2025-09-04 13:48:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134821.md




### 2025-09-04 13:48:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134822.md




### 2025-09-04 13:48:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134822.md




### 2025-09-04 13:48:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134822.md




### 2025-09-04 13:48:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134823.md




### 2025-09-04 13:48:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134824.md




### 2025-09-04 13:48:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134827.md




### 2025-09-04 13:48:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134827.md




### 2025-09-04 13:48:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134827.md




### 2025-09-04 13:48:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134828.md




### 2025-09-04 13:48:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134828.md




### 2025-09-04 13:48:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134830.md




### 2025-09-04 13:48:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134830.md




### 2025-09-04 13:48:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134831.md




### 2025-09-04 13:48:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134831.md




### 2025-09-04 13:48:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134831.md




### 2025-09-04 13:48:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134833.md




### 2025-09-04 13:48:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134834.md




### 2025-09-04 13:48:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134835.md




### 2025-09-04 13:48:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134836.md




### 2025-09-04 13:48:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134836.md




### 2025-09-04 13:48:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134837.md




### 2025-09-04 13:48:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134839.md




### 2025-09-04 13:48:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134841.md




### 2025-09-04 13:48:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134841.md




### 2025-09-04 13:48:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134841.md




### 2025-09-04 13:48:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134842.md




### 2025-09-04 13:48:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134842.md




### 2025-09-04 13:48:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134842.md




### 2025-09-04 13:48:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134845.md




### 2025-09-04 13:48:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134846.md




### 2025-09-04 13:48:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134847.md




### 2025-09-04 13:48:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134847.md




### 2025-09-04 13:48:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134848.md




### 2025-09-04 13:48:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134848.md




### 2025-09-04 13:48:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134849.md




### 2025-09-04 13:48:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134854.md




### 2025-09-04 13:48:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134855.md




### 2025-09-04 13:48:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134855.md




### 2025-09-04 13:48:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134856.md




### 2025-09-04 13:48:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134859.md




### 2025-09-04 13:49:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134900.md




### 2025-09-04 13:49:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134900.md




### 2025-09-04 13:49:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134900.md




### 2025-09-04 13:49:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134901.md




### 2025-09-04 13:49:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134902.md




### 2025-09-04 13:49:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134902.md




### 2025-09-04 13:49:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134904.md




### 2025-09-04 13:49:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134904.md




### 2025-09-04 13:49:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134904.md




### 2025-09-04 13:49:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134904.md




### 2025-09-04 13:49:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134904.md




### 2025-09-04 13:49:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134906.md




### 2025-09-04 13:49:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134906.md




### 2025-09-04 13:49:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134907.md




### 2025-09-04 13:49:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134909.md




### 2025-09-04 13:49:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134909.md




### 2025-09-04 13:49:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134909.md




### 2025-09-04 13:49:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134909.md




### 2025-09-04 13:49:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134910.md




### 2025-09-04 13:49:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134910.md




### 2025-09-04 13:49:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134910.md




### 2025-09-04 13:49:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134910.md




### 2025-09-04 13:49:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134911.md




### 2025-09-04 13:49:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134911.md




### 2025-09-04 13:49:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134911.md




### 2025-09-04 13:49:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134914.md




### 2025-09-04 13:49:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134914.md




### 2025-09-04 13:49:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134916.md




### 2025-09-04 13:49:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134918.md




### 2025-09-04 13:49:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134919.md




### 2025-09-04 13:49:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134920.md




### 2025-09-04 13:49:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134921.md




### 2025-09-04 13:49:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134921.md




### 2025-09-04 13:49:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134923.md




### 2025-09-04 13:49:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134924.md




### 2025-09-04 13:49:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134924.md




### 2025-09-04 13:49:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134924.md




### 2025-09-04 13:49:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134924.md




### 2025-09-04 13:49:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134925.md




### 2025-09-04 13:49:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134925.md




### 2025-09-04 13:49:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134928.md




### 2025-09-04 13:49:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134928.md




### 2025-09-04 13:49:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134929.md




### 2025-09-04 13:49:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134929.md




### 2025-09-04 13:49:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134930.md




### 2025-09-04 13:49:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134930.md




### 2025-09-04 13:49:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134931.md




### 2025-09-04 13:49:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134931.md




### 2025-09-04 13:49:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134931.md




### 2025-09-04 13:49:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134931.md




### 2025-09-04 13:49:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134933.md




### 2025-09-04 13:49:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134933.md




### 2025-09-04 13:49:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134934.md




### 2025-09-04 13:49:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134935.md




### 2025-09-04 13:49:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134936.md




### 2025-09-04 13:49:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134936.md




### 2025-09-04 13:49:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134936.md




### 2025-09-04 13:49:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134938.md




### 2025-09-04 13:49:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134938.md




### 2025-09-04 13:49:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134939.md




### 2025-09-04 13:49:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134939.md




### 2025-09-04 13:49:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134941.md




### 2025-09-04 13:49:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134941.md




### 2025-09-04 13:49:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134942.md




### 2025-09-04 13:49:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134942.md




### 2025-09-04 13:49:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134942.md




### 2025-09-04 13:49:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134945.md




### 2025-09-04 13:49:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134948.md




### 2025-09-04 13:49:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134948.md




### 2025-09-04 13:49:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134948.md




### 2025-09-04 13:49:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134948.md




### 2025-09-04 13:49:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134950.md




### 2025-09-04 13:49:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134951.md




### 2025-09-04 13:49:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134952.md




### 2025-09-04 13:49:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134952.md




### 2025-09-04 13:49:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134953.md




### 2025-09-04 13:49:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134953.md




### 2025-09-04 13:49:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134958.md




### 2025-09-04 13:49:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134958.md




### 2025-09-04 13:49:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-134959.md




### 2025-09-04 13:50:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135000.md




### 2025-09-04 13:50:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135003.md




### 2025-09-04 13:50:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135003.md




### 2025-09-04 13:50:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135004.md




### 2025-09-04 13:50:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135004.md




### 2025-09-04 13:50:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135005.md




### 2025-09-04 13:50:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135006.md




### 2025-09-04 13:50:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135007.md




### 2025-09-04 13:50:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135008.md




### 2025-09-04 13:50:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135010.md




### 2025-09-04 13:50:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135010.md




### 2025-09-04 13:50:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135011.md




### 2025-09-04 13:50:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135011.md




### 2025-09-04 13:50:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135012.md




### 2025-09-04 13:50:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135012.md




### 2025-09-04 13:50:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135013.md




### 2025-09-04 13:50:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135013.md




### 2025-09-04 13:50:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135013.md




### 2025-09-04 13:50:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135013.md




### 2025-09-04 13:50:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135014.md




### 2025-09-04 13:50:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135014.md




### 2025-09-04 13:50:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135015.md




### 2025-09-04 13:50:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135016.md




### 2025-09-04 13:50:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135016.md




### 2025-09-04 13:50:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135016.md




### 2025-09-04 13:50:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135016.md




### 2025-09-04 13:50:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135017.md




### 2025-09-04 13:50:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135017.md




### 2025-09-04 13:50:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135018.md




### 2025-09-04 13:50:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135020.md




### 2025-09-04 13:50:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135020.md




### 2025-09-04 13:50:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135020.md




### 2025-09-04 13:50:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135021.md




### 2025-09-04 13:50:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135021.md




### 2025-09-04 13:50:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135022.md




### 2025-09-04 13:50:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135023.md




### 2025-09-04 13:50:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135024.md




### 2025-09-04 13:50:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135025.md




### 2025-09-04 13:50:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135025.md




### 2025-09-04 13:50:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135027.md




### 2025-09-04 13:50:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135027.md




### 2025-09-04 13:50:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135029.md




### 2025-09-04 13:50:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135029.md




### 2025-09-04 13:50:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135030.md




### 2025-09-04 13:50:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135030.md




### 2025-09-04 13:50:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135032.md




### 2025-09-04 13:50:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135033.md




### 2025-09-04 13:50:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135034.md




### 2025-09-04 13:50:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135034.md




### 2025-09-04 13:50:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135035.md




### 2025-09-04 13:50:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135035.md




### 2025-09-04 13:50:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135035.md




### 2025-09-04 13:50:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135036.md




### 2025-09-04 13:50:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135036.md




### 2025-09-04 13:50:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135036.md




### 2025-09-04 13:50:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135038.md




### 2025-09-04 13:50:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135039.md




### 2025-09-04 13:50:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135040.md




### 2025-09-04 13:50:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135041.md




### 2025-09-04 13:50:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135042.md




### 2025-09-04 13:50:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135042.md




### 2025-09-04 13:50:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135043.md




### 2025-09-04 13:50:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135044.md




### 2025-09-04 13:50:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135044.md




### 2025-09-04 13:50:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135044.md




### 2025-09-04 13:50:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135045.md




### 2025-09-04 13:50:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135045.md




### 2025-09-04 13:50:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135045.md




### 2025-09-04 13:50:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135045.md




### 2025-09-04 13:50:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135046.md




### 2025-09-04 13:50:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135046.md




### 2025-09-04 13:50:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135047.md




### 2025-09-04 13:50:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135047.md




### 2025-09-04 13:50:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135049.md




### 2025-09-04 13:50:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135049.md




### 2025-09-04 13:50:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135052.md




### 2025-09-04 13:50:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135054.md




### 2025-09-04 13:50:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135055.md




### 2025-09-04 13:50:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135055.md




### 2025-09-04 13:50:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135055.md




### 2025-09-04 13:50:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135055.md




### 2025-09-04 13:50:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135056.md




### 2025-09-04 13:50:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135056.md




### 2025-09-04 13:50:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135056.md




### 2025-09-04 13:50:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135056.md




### 2025-09-04 13:50:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135057.md




### 2025-09-04 13:50:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135057.md




### 2025-09-04 13:50:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135058.md




### 2025-09-04 13:50:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135059.md




### 2025-09-04 13:50:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135059.md




### 2025-09-04 13:50:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135059.md




### 2025-09-04 13:51:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135100.md




### 2025-09-04 13:51:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135100.md




### 2025-09-04 13:51:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135101.md




### 2025-09-04 13:51:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135101.md




### 2025-09-04 13:51:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135101.md




### 2025-09-04 13:51:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135103.md




### 2025-09-04 13:51:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135103.md




### 2025-09-04 13:51:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135103.md




### 2025-09-04 13:51:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135104.md




### 2025-09-04 13:51:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135105.md




### 2025-09-04 13:51:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135107.md




### 2025-09-04 13:51:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135107.md




### 2025-09-04 13:51:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135108.md




### 2025-09-04 13:51:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135109.md




### 2025-09-04 13:51:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135109.md




### 2025-09-04 13:51:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135110.md




### 2025-09-04 13:51:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135111.md




### 2025-09-04 13:51:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135111.md




### 2025-09-04 13:51:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135111.md




### 2025-09-04 13:51:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135112.md




### 2025-09-04 13:51:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135112.md




### 2025-09-04 13:51:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135114.md




### 2025-09-04 13:51:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135114.md




### 2025-09-04 13:51:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135115.md




### 2025-09-04 13:51:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135115.md




### 2025-09-04 13:51:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135115.md




### 2025-09-04 13:51:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135115.md




### 2025-09-04 13:51:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135116.md




### 2025-09-04 13:51:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135117.md




### 2025-09-04 13:51:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135118.md




### 2025-09-04 13:51:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135118.md




### 2025-09-04 13:51:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135119.md




### 2025-09-04 13:51:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135120.md




### 2025-09-04 13:51:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135121.md




### 2025-09-04 13:51:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135122.md




### 2025-09-04 13:51:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135122.md




### 2025-09-04 13:51:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135123.md




### 2025-09-04 13:51:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135126.md




### 2025-09-04 13:51:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135127.md




### 2025-09-04 13:51:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135128.md




### 2025-09-04 13:51:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135131.md




### 2025-09-04 13:51:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135134.md




### 2025-09-04 13:51:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135134.md




### 2025-09-04 13:51:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135134.md




### 2025-09-04 13:51:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135135.md




### 2025-09-04 13:51:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135136.md




### 2025-09-04 13:51:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135138.md




### 2025-09-04 13:51:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135139.md




### 2025-09-04 13:51:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135139.md




### 2025-09-04 13:51:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135141.md




### 2025-09-04 13:51:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135141.md




### 2025-09-04 13:51:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135142.md




### 2025-09-04 13:51:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135143.md




### 2025-09-04 13:51:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135143.md




### 2025-09-04 13:51:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135143.md




### 2025-09-04 13:51:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135144.md




### 2025-09-04 13:51:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135145.md




### 2025-09-04 13:51:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135145.md




### 2025-09-04 13:51:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135146.md




### 2025-09-04 13:51:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135146.md




### 2025-09-04 13:51:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135146.md




### 2025-09-04 13:51:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135147.md




### 2025-09-04 13:51:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135147.md




### 2025-09-04 13:51:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135147.md




### 2025-09-04 13:51:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135148.md




### 2025-09-04 13:51:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135148.md




### 2025-09-04 13:51:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135149.md




### 2025-09-04 13:51:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135149.md




### 2025-09-04 13:51:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135150.md




### 2025-09-04 13:51:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135152.md




### 2025-09-04 13:51:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135152.md




### 2025-09-04 13:51:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135152.md




### 2025-09-04 13:51:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135153.md




### 2025-09-04 13:51:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135154.md




### 2025-09-04 13:51:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135155.md




### 2025-09-04 13:51:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135155.md




### 2025-09-04 13:51:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135155.md




### 2025-09-04 13:51:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135156.md




### 2025-09-04 13:51:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135156.md




### 2025-09-04 13:51:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135157.md




### 2025-09-04 13:51:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135158.md




### 2025-09-04 13:51:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135158.md




### 2025-09-04 13:51:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135158.md




### 2025-09-04 13:51:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135159.md




### 2025-09-04 13:51:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135159.md




### 2025-09-04 13:52:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135200.md




### 2025-09-04 13:52:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135201.md




### 2025-09-04 13:52:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135201.md




### 2025-09-04 13:52:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135201.md




### 2025-09-04 13:52:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135202.md




### 2025-09-04 13:52:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135202.md




### 2025-09-04 13:52:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135202.md




### 2025-09-04 13:52:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135203.md




### 2025-09-04 13:52:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135203.md




### 2025-09-04 13:52:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135203.md




### 2025-09-04 13:52:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135205.md




### 2025-09-04 13:52:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135205.md




### 2025-09-04 13:52:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135205.md




### 2025-09-04 13:52:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135205.md




### 2025-09-04 13:52:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135206.md




### 2025-09-04 13:52:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135208.md




### 2025-09-04 13:52:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135208.md




### 2025-09-04 13:52:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135209.md




### 2025-09-04 13:52:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135210.md




### 2025-09-04 13:52:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135211.md




### 2025-09-04 13:52:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135212.md




### 2025-09-04 13:52:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135213.md




### 2025-09-04 13:52:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135213.md




### 2025-09-04 13:52:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135213.md




### 2025-09-04 13:52:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135214.md




### 2025-09-04 13:52:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135215.md




### 2025-09-04 13:52:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135215.md




### 2025-09-04 13:52:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135216.md




### 2025-09-04 13:52:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135217.md




### 2025-09-04 13:52:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135217.md




### 2025-09-04 13:52:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135218.md




### 2025-09-04 13:52:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135219.md




### 2025-09-04 13:52:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135219.md




### 2025-09-04 13:52:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135219.md




### 2025-09-04 13:52:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135220.md




### 2025-09-04 13:52:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135221.md




### 2025-09-04 13:52:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135221.md




### 2025-09-04 13:52:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135222.md




### 2025-09-04 13:52:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135222.md




### 2025-09-04 13:52:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135222.md




### 2025-09-04 13:52:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135225.md




### 2025-09-04 13:52:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135226.md




### 2025-09-04 13:52:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135227.md




### 2025-09-04 13:52:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135228.md




### 2025-09-04 13:52:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135228.md




### 2025-09-04 13:52:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135230.md




### 2025-09-04 13:52:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135232.md




### 2025-09-04 13:52:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135232.md




### 2025-09-04 13:52:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135234.md




### 2025-09-04 13:52:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135234.md




### 2025-09-04 13:52:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135235.md




### 2025-09-04 13:52:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135235.md




### 2025-09-04 13:52:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135236.md




### 2025-09-04 13:52:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135237.md




### 2025-09-04 13:52:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135237.md




### 2025-09-04 13:52:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135239.md




### 2025-09-04 13:52:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135239.md




### 2025-09-04 13:52:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135240.md




### 2025-09-04 13:52:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135240.md




### 2025-09-04 13:52:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135243.md




### 2025-09-04 13:52:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135244.md




### 2025-09-04 13:52:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135245.md




### 2025-09-04 13:52:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135246.md




### 2025-09-04 13:52:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135246.md




### 2025-09-04 13:52:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135247.md




### 2025-09-04 13:52:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135250.md




### 2025-09-04 13:52:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135250.md




### 2025-09-04 13:52:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135251.md




### 2025-09-04 13:52:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135251.md




### 2025-09-04 13:52:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135252.md




### 2025-09-04 13:52:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135252.md




### 2025-09-04 13:52:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135254.md




### 2025-09-04 13:52:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135255.md




### 2025-09-04 13:52:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135256.md




### 2025-09-04 13:52:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135258.md




### 2025-09-04 13:52:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135258.md




### 2025-09-04 13:52:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135259.md




### 2025-09-04 13:53:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135300.md




### 2025-09-04 13:53:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135300.md




### 2025-09-04 13:53:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135301.md




### 2025-09-04 13:53:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135302.md




### 2025-09-04 13:53:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135303.md




### 2025-09-04 13:53:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135303.md




### 2025-09-04 13:53:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135304.md




### 2025-09-04 13:53:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135305.md




### 2025-09-04 13:53:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135305.md




### 2025-09-04 13:53:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135306.md




### 2025-09-04 13:53:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135306.md




### 2025-09-04 13:53:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135306.md




### 2025-09-04 13:53:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135307.md




### 2025-09-04 13:53:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135308.md




### 2025-09-04 13:53:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135308.md




### 2025-09-04 13:53:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135309.md




### 2025-09-04 13:53:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135310.md




### 2025-09-04 13:53:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135312.md




### 2025-09-04 13:53:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135312.md




### 2025-09-04 13:53:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135312.md




### 2025-09-04 13:53:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135314.md




### 2025-09-04 13:53:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135315.md




### 2025-09-04 13:53:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135315.md




### 2025-09-04 13:53:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135315.md




### 2025-09-04 13:53:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135317.md




### 2025-09-04 13:53:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135317.md




### 2025-09-04 13:53:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135317.md




### 2025-09-04 13:53:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135318.md




### 2025-09-04 13:53:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135318.md




### 2025-09-04 13:53:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135320.md




### 2025-09-04 13:53:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135320.md




### 2025-09-04 13:53:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135321.md




### 2025-09-04 13:53:21
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135321.md




### 2025-09-04 13:53:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135322.md




### 2025-09-04 13:53:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135323.md




### 2025-09-04 13:53:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135325.md




### 2025-09-04 13:53:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135327.md




### 2025-09-04 13:53:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135327.md




### 2025-09-04 13:53:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135328.md




### 2025-09-04 13:53:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135328.md




### 2025-09-04 13:53:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135329.md




### 2025-09-04 13:53:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135329.md




### 2025-09-04 13:53:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135332.md




### 2025-09-04 13:53:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135334.md




### 2025-09-04 13:53:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135336.md




### 2025-09-04 13:53:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135337.md




### 2025-09-04 13:53:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135338.md




### 2025-09-04 13:53:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135338.md




### 2025-09-04 13:53:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135338.md




### 2025-09-04 13:53:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135339.md




### 2025-09-04 13:53:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135340.md




### 2025-09-04 13:53:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135340.md




### 2025-09-04 13:53:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135341.md




### 2025-09-04 13:53:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135341.md




### 2025-09-04 13:53:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135341.md




### 2025-09-04 13:53:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135341.md




### 2025-09-04 13:53:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135341.md




### 2025-09-04 13:53:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135342.md




### 2025-09-04 13:53:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135342.md




### 2025-09-04 13:53:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135342.md




### 2025-09-04 13:53:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135342.md




### 2025-09-04 13:53:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135342.md




### 2025-09-04 13:53:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135343.md




### 2025-09-04 13:53:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135344.md




### 2025-09-04 13:53:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135345.md




### 2025-09-04 13:53:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135345.md




### 2025-09-04 13:53:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135345.md




### 2025-09-04 13:53:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135347.md




### 2025-09-04 13:53:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135347.md




### 2025-09-04 13:53:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135348.md




### 2025-09-04 13:53:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135348.md




### 2025-09-04 13:53:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135349.md




### 2025-09-04 13:53:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135349.md




### 2025-09-04 13:53:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135352.md




### 2025-09-04 13:53:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135352.md




### 2025-09-04 13:53:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135354.md




### 2025-09-04 13:53:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135355.md




### 2025-09-04 13:53:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135356.md




### 2025-09-04 13:53:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135357.md




### 2025-09-04 13:53:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135357.md




### 2025-09-04 13:54:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135401.md




### 2025-09-04 13:54:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135402.md




### 2025-09-04 13:54:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135403.md




### 2025-09-04 13:54:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135405.md




### 2025-09-04 13:54:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135406.md




### 2025-09-04 13:54:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135411.md




### 2025-09-04 13:54:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135411.md




### 2025-09-04 13:54:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135412.md




### 2025-09-04 13:54:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135415.md




### 2025-09-04 13:54:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135415.md




### 2025-09-04 13:54:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135416.md




### 2025-09-04 13:54:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135416.md




### 2025-09-04 13:54:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135416.md




### 2025-09-04 13:54:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135417.md




### 2025-09-04 13:54:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135417.md




### 2025-09-04 13:54:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135418.md




### 2025-09-04 13:54:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135420.md




### 2025-09-04 13:54:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135420.md




### 2025-09-04 13:54:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135422.md




### 2025-09-04 13:54:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135422.md




### 2025-09-04 13:54:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135424.md




### 2025-09-04 13:54:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135425.md




### 2025-09-04 13:54:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135426.md




### 2025-09-04 13:54:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135427.md




### 2025-09-04 13:54:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135427.md




### 2025-09-04 13:54:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135427.md




### 2025-09-04 13:54:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135427.md




### 2025-09-04 13:54:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135428.md




### 2025-09-04 13:54:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135428.md




### 2025-09-04 13:54:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135433.md




### 2025-09-04 13:54:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135433.md




### 2025-09-04 13:54:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135438.md




### 2025-09-04 13:54:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135439.md




### 2025-09-04 13:54:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135440.md




### 2025-09-04 13:54:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135441.md




### 2025-09-04 13:54:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135441.md




### 2025-09-04 13:54:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135443.md




### 2025-09-04 13:54:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135443.md




### 2025-09-04 13:54:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135443.md




### 2025-09-04 13:54:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135445.md




### 2025-09-04 13:54:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135445.md




### 2025-09-04 13:54:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135448.md




### 2025-09-04 13:54:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135449.md




### 2025-09-04 13:54:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135451.md




### 2025-09-04 13:54:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135451.md




### 2025-09-04 13:54:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135454.md




### 2025-09-04 13:54:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135454.md




### 2025-09-04 13:54:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135454.md




### 2025-09-04 13:54:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135454.md




### 2025-09-04 13:55:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135500.md




### 2025-09-04 13:55:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135500.md




### 2025-09-04 13:55:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135500.md




### 2025-09-04 13:55:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135502.md




### 2025-09-04 13:55:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135503.md




### 2025-09-04 13:55:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135503.md




### 2025-09-04 13:55:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135503.md




### 2025-09-04 13:55:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135503.md




### 2025-09-04 13:55:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135504.md




### 2025-09-04 13:55:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135506.md




### 2025-09-04 13:55:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135507.md




### 2025-09-04 13:55:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135507.md




### 2025-09-04 13:55:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135508.md




### 2025-09-04 13:55:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135511.md




### 2025-09-04 13:55:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135511.md




### 2025-09-04 13:55:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135512.md




### 2025-09-04 13:55:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135512.md




### 2025-09-04 13:55:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135512.md




### 2025-09-04 13:55:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135512.md




### 2025-09-04 13:55:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135513.md




### 2025-09-04 13:55:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135513.md




### 2025-09-04 13:55:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135514.md




### 2025-09-04 13:55:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135515.md




### 2025-09-04 13:55:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135515.md




### 2025-09-04 13:55:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135515.md




### 2025-09-04 13:55:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135516.md




### 2025-09-04 13:55:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135516.md




### 2025-09-04 13:55:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135518.md




### 2025-09-04 13:55:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135519.md




### 2025-09-04 13:55:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135520.md




### 2025-09-04 13:55:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135522.md




### 2025-09-04 13:55:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135523.md




### 2025-09-04 13:55:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135523.md




### 2025-09-04 13:55:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135524.md




### 2025-09-04 13:55:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135524.md




### 2025-09-04 13:55:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135527.md




### 2025-09-04 13:55:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135528.md




### 2025-09-04 13:55:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135530.md




### 2025-09-04 13:55:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135533.md




### 2025-09-04 13:55:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135533.md




### 2025-09-04 13:55:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135535.md




### 2025-09-04 13:55:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135535.md




### 2025-09-04 13:55:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135535.md




### 2025-09-04 13:55:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135535.md




### 2025-09-04 13:55:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135536.md




### 2025-09-04 13:55:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135538.md




### 2025-09-04 13:55:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135538.md




### 2025-09-04 13:55:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135539.md




### 2025-09-04 13:55:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135539.md




### 2025-09-04 13:55:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135542.md




### 2025-09-04 13:55:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135542.md




### 2025-09-04 13:55:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135542.md




### 2025-09-04 13:55:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135543.md




### 2025-09-04 13:55:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135543.md




### 2025-09-04 13:55:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135544.md




### 2025-09-04 13:55:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135544.md




### 2025-09-04 13:55:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135544.md




### 2025-09-04 13:55:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135546.md




### 2025-09-04 13:55:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135547.md




### 2025-09-04 13:55:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135548.md




### 2025-09-04 13:55:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135549.md




### 2025-09-04 13:55:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135549.md




### 2025-09-04 13:55:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135549.md




### 2025-09-04 13:55:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135549.md




### 2025-09-04 13:55:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135550.md




### 2025-09-04 13:55:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135550.md




### 2025-09-04 13:55:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135550.md




### 2025-09-04 13:55:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135552.md




### 2025-09-04 13:55:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135552.md




### 2025-09-04 13:55:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135553.md




### 2025-09-04 13:55:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135553.md




### 2025-09-04 13:55:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135554.md




### 2025-09-04 13:55:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135555.md




### 2025-09-04 13:55:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135555.md




### 2025-09-04 13:55:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135556.md




### 2025-09-04 13:55:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135556.md




### 2025-09-04 13:55:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135556.md




### 2025-09-04 13:55:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135556.md




### 2025-09-04 13:55:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135557.md




### 2025-09-04 13:55:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135557.md




### 2025-09-04 13:55:58
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135558.md




### 2025-09-04 13:55:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135559.md




### 2025-09-04 13:55:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135559.md




### 2025-09-04 13:55:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135559.md




### 2025-09-04 13:56:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135600.md




### 2025-09-04 13:56:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135602.md




### 2025-09-04 13:56:02
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135602.md




### 2025-09-04 13:56:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135603.md




### 2025-09-04 13:56:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135604.md




### 2025-09-04 13:56:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135605.md




### 2025-09-04 13:56:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135606.md




### 2025-09-04 13:56:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135607.md




### 2025-09-04 13:56:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135607.md




### 2025-09-04 13:56:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135608.md




### 2025-09-04 13:56:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135608.md




### 2025-09-04 13:56:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135608.md




### 2025-09-04 13:56:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135609.md




### 2025-09-04 13:56:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135609.md




### 2025-09-04 13:56:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135609.md




### 2025-09-04 13:56:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135610.md




### 2025-09-04 13:56:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135610.md




### 2025-09-04 13:56:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135611.md




### 2025-09-04 13:56:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135612.md




### 2025-09-04 13:56:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135612.md




### 2025-09-04 13:56:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135612.md




### 2025-09-04 13:56:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135613.md




### 2025-09-04 13:56:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135614.md




### 2025-09-04 13:56:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135614.md




### 2025-09-04 13:56:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135615.md




### 2025-09-04 13:56:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135615.md




### 2025-09-04 13:56:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135616.md




### 2025-09-04 13:56:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135616.md




### 2025-09-04 13:56:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135616.md




### 2025-09-04 13:56:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135622.md




### 2025-09-04 13:56:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135626.md




### 2025-09-04 13:56:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135626.md




### 2025-09-04 13:56:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135626.md




### 2025-09-04 13:56:26
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135626.md




### 2025-09-04 13:56:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135627.md




### 2025-09-04 13:56:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135627.md




### 2025-09-04 13:56:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135628.md




### 2025-09-04 13:56:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135629.md




### 2025-09-04 13:56:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135632.md




### 2025-09-04 13:56:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135633.md




### 2025-09-04 13:56:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135634.md




### 2025-09-04 13:56:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135636.md




### 2025-09-04 13:56:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135636.md




### 2025-09-04 13:56:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135637.md




### 2025-09-04 13:56:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135638.md




### 2025-09-04 13:56:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135639.md




### 2025-09-04 13:56:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135640.md




### 2025-09-04 13:56:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135640.md




### 2025-09-04 13:56:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135641.md




### 2025-09-04 13:56:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135643.md




### 2025-09-04 13:56:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135643.md




### 2025-09-04 13:56:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135644.md




### 2025-09-04 13:56:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135645.md




### 2025-09-04 13:56:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135646.md




### 2025-09-04 13:56:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135647.md




### 2025-09-04 13:56:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135647.md




### 2025-09-04 13:56:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135647.md




### 2025-09-04 13:56:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135648.md




### 2025-09-04 13:56:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135648.md




### 2025-09-04 13:56:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135649.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135650.md




### 2025-09-04 13:56:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135652.md




### 2025-09-04 13:56:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135653.md




### 2025-09-04 13:56:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135653.md




### 2025-09-04 13:56:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135654.md




### 2025-09-04 13:56:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135657.md




### 2025-09-04 13:57:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135700.md




### 2025-09-04 13:57:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135700.md




### 2025-09-04 13:57:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135701.md




### 2025-09-04 13:57:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135703.md




### 2025-09-04 13:57:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135703.md




### 2025-09-04 13:57:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135706.md




### 2025-09-04 13:57:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135706.md




### 2025-09-04 13:57:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135708.md




### 2025-09-04 13:57:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135709.md




### 2025-09-04 13:57:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135709.md




### 2025-09-04 13:57:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135710.md




### 2025-09-04 13:57:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135710.md




### 2025-09-04 13:57:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135711.md




### 2025-09-04 13:57:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135711.md




### 2025-09-04 13:57:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135715.md




### 2025-09-04 13:57:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135715.md




### 2025-09-04 13:57:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135718.md




### 2025-09-04 13:57:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135718.md




### 2025-09-04 13:57:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135718.md




### 2025-09-04 13:57:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135718.md




### 2025-09-04 13:57:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135719.md




### 2025-09-04 13:57:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135719.md




### 2025-09-04 13:57:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135720.md




### 2025-09-04 13:57:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135722.md




### 2025-09-04 13:57:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135722.md




### 2025-09-04 13:57:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135723.md




### 2025-09-04 13:57:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135723.md




### 2025-09-04 13:57:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135725.md




### 2025-09-04 13:57:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135727.md




### 2025-09-04 13:57:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135727.md




### 2025-09-04 13:57:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135727.md




### 2025-09-04 13:57:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135729.md




### 2025-09-04 13:57:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135729.md




### 2025-09-04 13:57:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135730.md




### 2025-09-04 13:57:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135731.md




### 2025-09-04 13:57:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135733.md




### 2025-09-04 13:57:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135734.md




### 2025-09-04 13:57:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135734.md




### 2025-09-04 13:57:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135734.md




### 2025-09-04 13:57:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135734.md




### 2025-09-04 13:57:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135734.md




### 2025-09-04 13:57:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135736.md




### 2025-09-04 13:57:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135736.md




### 2025-09-04 13:57:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135736.md




### 2025-09-04 13:57:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135738.md




### 2025-09-04 13:57:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135739.md




### 2025-09-04 13:57:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135739.md




### 2025-09-04 13:57:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135740.md




### 2025-09-04 13:57:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135741.md




### 2025-09-04 13:57:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135741.md




### 2025-09-04 13:57:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135741.md




### 2025-09-04 13:57:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135743.md




### 2025-09-04 13:57:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135744.md




### 2025-09-04 13:57:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135744.md




### 2025-09-04 13:57:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135745.md




### 2025-09-04 13:57:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135745.md




### 2025-09-04 13:57:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135745.md




### 2025-09-04 13:57:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135745.md




### 2025-09-04 13:57:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135749.md




### 2025-09-04 13:57:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135749.md




### 2025-09-04 13:57:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135749.md




### 2025-09-04 13:57:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135750.md




### 2025-09-04 13:57:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135751.md




### 2025-09-04 13:57:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135751.md




### 2025-09-04 13:57:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135752.md




### 2025-09-04 13:57:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135752.md




### 2025-09-04 13:57:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135753.md




### 2025-09-04 13:57:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135753.md




### 2025-09-04 13:57:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135753.md




### 2025-09-04 13:57:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135754.md




### 2025-09-04 13:57:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135756.md




### 2025-09-04 13:57:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135756.md




### 2025-09-04 13:57:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135756.md




### 2025-09-04 13:57:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135759.md




### 2025-09-04 13:57:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135759.md




### 2025-09-04 13:58:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135801.md




### 2025-09-04 13:58:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135801.md




### 2025-09-04 13:58:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135801.md




### 2025-09-04 13:58:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135804.md




### 2025-09-04 13:58:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135804.md




### 2025-09-04 13:58:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135806.md




### 2025-09-04 13:58:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135807.md




### 2025-09-04 13:58:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135810.md




### 2025-09-04 13:58:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135811.md




### 2025-09-04 13:58:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135812.md




### 2025-09-04 13:58:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135812.md




### 2025-09-04 13:58:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135812.md




### 2025-09-04 13:58:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135813.md




### 2025-09-04 13:58:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135813.md




### 2025-09-04 13:58:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135813.md




### 2025-09-04 13:58:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135814.md




### 2025-09-04 13:58:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135816.md




### 2025-09-04 13:58:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135818.md




### 2025-09-04 13:58:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135819.md




### 2025-09-04 13:58:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135820.md




### 2025-09-04 13:58:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135820.md




### 2025-09-04 13:58:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135824.md




### 2025-09-04 13:58:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135825.md




### 2025-09-04 13:58:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135825.md




### 2025-09-04 13:58:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135825.md




### 2025-09-04 13:58:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135827.md




### 2025-09-04 13:58:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135827.md




### 2025-09-04 13:58:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135827.md




### 2025-09-04 13:58:29
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135829.md




### 2025-09-04 13:58:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135830.md




### 2025-09-04 13:58:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135831.md




### 2025-09-04 13:58:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135831.md




### 2025-09-04 13:58:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135832.md




### 2025-09-04 13:58:33
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135833.md




### 2025-09-04 13:58:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135834.md




### 2025-09-04 13:58:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135834.md




### 2025-09-04 13:58:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135834.md




### 2025-09-04 13:58:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135835.md




### 2025-09-04 13:58:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135835.md




### 2025-09-04 13:58:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135835.md




### 2025-09-04 13:58:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135835.md




### 2025-09-04 13:58:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135836.md




### 2025-09-04 13:58:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135836.md




### 2025-09-04 13:58:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135838.md




### 2025-09-04 13:58:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135838.md




### 2025-09-04 13:58:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135839.md




### 2025-09-04 13:58:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135839.md




### 2025-09-04 13:58:39
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135839.md




### 2025-09-04 13:58:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135841.md




### 2025-09-04 13:58:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135842.md




### 2025-09-04 13:58:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135842.md




### 2025-09-04 13:58:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135843.md




### 2025-09-04 13:58:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135844.md




### 2025-09-04 13:58:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135846.md




### 2025-09-04 13:58:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135846.md




### 2025-09-04 13:58:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135847.md




### 2025-09-04 13:58:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135848.md




### 2025-09-04 13:58:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135848.md




### 2025-09-04 13:58:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135849.md




### 2025-09-04 13:58:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135850.md




### 2025-09-04 13:58:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135851.md




### 2025-09-04 13:58:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135851.md




### 2025-09-04 13:58:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135851.md




### 2025-09-04 13:58:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135854.md




### 2025-09-04 13:58:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135854.md




### 2025-09-04 13:58:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135856.md




### 2025-09-04 13:58:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135857.md




### 2025-09-04 13:58:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135857.md




### 2025-09-04 13:58:57
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135857.md




### 2025-09-04 13:58:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135859.md




### 2025-09-04 13:59:00
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135900.md




### 2025-09-04 13:59:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135903.md




### 2025-09-04 13:59:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135904.md




### 2025-09-04 13:59:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135904.md




### 2025-09-04 13:59:05
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135905.md




### 2025-09-04 13:59:06
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135906.md




### 2025-09-04 13:59:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135907.md




### 2025-09-04 13:59:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135907.md




### 2025-09-04 13:59:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135907.md




### 2025-09-04 13:59:07
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135907.md




### 2025-09-04 13:59:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135908.md




### 2025-09-04 13:59:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135909.md




### 2025-09-04 13:59:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135909.md




### 2025-09-04 13:59:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135910.md




### 2025-09-04 13:59:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135910.md




### 2025-09-04 13:59:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135911.md




### 2025-09-04 13:59:11
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135911.md




### 2025-09-04 13:59:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135912.md




### 2025-09-04 13:59:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135913.md




### 2025-09-04 13:59:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135914.md




### 2025-09-04 13:59:14
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135914.md




### 2025-09-04 13:59:15
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135915.md




### 2025-09-04 13:59:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135916.md




### 2025-09-04 13:59:16
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135916.md




### 2025-09-04 13:59:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135917.md




### 2025-09-04 13:59:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135918.md




### 2025-09-04 13:59:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135920.md




### 2025-09-04 13:59:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135920.md




### 2025-09-04 13:59:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135922.md




### 2025-09-04 13:59:28
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135928.md




### 2025-09-04 13:59:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135930.md




### 2025-09-04 13:59:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135932.md




### 2025-09-04 13:59:32
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135932.md




### 2025-09-04 13:59:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135934.md




### 2025-09-04 13:59:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135934.md




### 2025-09-04 13:59:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135935.md




### 2025-09-04 13:59:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135937.md




### 2025-09-04 13:59:38
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135938.md




### 2025-09-04 13:59:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135940.md




### 2025-09-04 13:59:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135940.md




### 2025-09-04 13:59:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135942.md




### 2025-09-04 13:59:42
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135942.md




### 2025-09-04 13:59:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135943.md




### 2025-09-04 13:59:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135943.md




### 2025-09-04 13:59:43
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135943.md




### 2025-09-04 13:59:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135945.md




### 2025-09-04 13:59:46
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135946.md




### 2025-09-04 13:59:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135948.md




### 2025-09-04 13:59:48
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135948.md




### 2025-09-04 13:59:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135949.md




### 2025-09-04 13:59:51
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135951.md




### 2025-09-04 13:59:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135952.md




### 2025-09-04 13:59:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135954.md




### 2025-09-04 13:59:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135954.md




### 2025-09-04 13:59:55
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135955.md




### 2025-09-04 13:59:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135956.md




### 2025-09-04 13:59:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135956.md




### 2025-09-04 13:59:59
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-135959.md




### 2025-09-04 14:00:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140001.md




### 2025-09-04 14:00:01
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140001.md




### 2025-09-04 14:00:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140003.md




### 2025-09-04 14:00:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140003.md




### 2025-09-04 14:00:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140003.md




### 2025-09-04 14:00:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140003.md




### 2025-09-04 14:00:03
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140003.md




### 2025-09-04 14:00:04
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140004.md




### 2025-09-04 14:00:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140008.md




### 2025-09-04 14:00:08
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140008.md




### 2025-09-04 14:00:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140009.md




### 2025-09-04 14:00:09
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140009.md




### 2025-09-04 14:00:10
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140010.md




### 2025-09-04 14:00:12
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140012.md




### 2025-09-04 14:00:13
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140013.md




### 2025-09-04 14:00:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140017.md




### 2025-09-04 14:00:17
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140017.md




### 2025-09-04 14:00:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140018.md




### 2025-09-04 14:00:18
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140018.md




### 2025-09-04 14:00:19
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140019.md




### 2025-09-04 14:00:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140020.md




### 2025-09-04 14:00:20
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140020.md




### 2025-09-04 14:00:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140022.md




### 2025-09-04 14:00:22
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140022.md




### 2025-09-04 14:00:23
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140023.md




### 2025-09-04 14:00:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140024.md




### 2025-09-04 14:00:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140024.md




### 2025-09-04 14:00:24
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140024.md




### 2025-09-04 14:00:25
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140025.md




### 2025-09-04 14:00:27
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140027.md




### 2025-09-04 14:00:30
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140030.md




### 2025-09-04 14:00:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140031.md




### 2025-09-04 14:00:31
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140031.md




### 2025-09-04 14:00:34
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140034.md




### 2025-09-04 14:00:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140035.md




### 2025-09-04 14:00:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140035.md




### 2025-09-04 14:00:35
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140035.md




### 2025-09-04 14:00:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140036.md




### 2025-09-04 14:00:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140036.md




### 2025-09-04 14:00:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140036.md




### 2025-09-04 14:00:36
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140036.md




### 2025-09-04 14:00:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140037.md




### 2025-09-04 14:00:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140037.md




### 2025-09-04 14:00:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140037.md




### 2025-09-04 14:00:37
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140037.md




### 2025-09-04 14:00:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140040.md




### 2025-09-04 14:00:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140040.md




### 2025-09-04 14:00:40
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140040.md




### 2025-09-04 14:00:41
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140041.md




### 2025-09-04 14:00:44
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140044.md




### 2025-09-04 14:00:45
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140045.md




### 2025-09-04 14:00:47
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140047.md




### 2025-09-04 14:00:49
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140049.md




### 2025-09-04 14:00:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140050.md




### 2025-09-04 14:00:50
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140050.md




### 2025-09-04 14:00:52
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140052.md




### 2025-09-04 14:00:53
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140053.md




### 2025-09-04 14:00:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140054.md




### 2025-09-04 14:00:54
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140054.md




### 2025-09-04 14:00:56
#### AutoSplit
- Kilde: dump-1.md
- Antall seksjoner: 2
- Fil: autosplit-20250904-140056.md

