## Ops → dev-platform : kort status og next steps

**Bakgrunn:** Migrasjonen og autosplit er nå gjennomført for siste batch. Vi ønsker bekreftelse på at dere kan ta inn 1–2 mindre oppgaver fra *ideer-lab* denne uken.

**Foreslått next:**
- Verifiser at dev-platform ser siste autosplit (minst 10–15 filer).
- Gi estimat på kapasitet (småting fra ideer-lab).
- Bekreft at product-roadmap kobler riktig epics til dere.

_Svar gjerne med kort status og avhengigheter._
