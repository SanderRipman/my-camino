## Ops → dev-platform : kort status og kapasitet
- Bekreft at dere ser siste autosplit (≈13+ filer i captures).
- Har dere kapasitet til 1–2 små fra ideer-lab denne uken?
- Eventuelle avhengigheter (data/design/beslutning).
