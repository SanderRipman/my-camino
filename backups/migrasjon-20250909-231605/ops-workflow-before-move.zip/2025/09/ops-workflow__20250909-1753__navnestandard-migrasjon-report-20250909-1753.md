# Navnestandard + migrasjonsrydd (UTFØR) – 20250909-1753

| ChatKey | Flyttet | Skippet | Standard-navn | Backup |
|---|---:|---:|---:|---|
| ops-workflow | 0 | 3 | 0 | C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250909-1753.zip |
| dev-platform | 0 | 0 | 0 | C:\Dev\my-camino\handover\backups\dev-platform-captures-backup-20250909-1753.zip |
| product-roadmap | 0 | 0 | 0 | C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250909-1753.zip |
| turplan-camino | 0 | 0 | 0 | C:\Dev\my-camino\handover\backups\turplan-camino-captures-backup-20250909-1753.zip |
