# Utkast-dispatch — sammendrag
Kjørt : 2025-09-09 21:06:47
Root  : C:\Dev\my-camino
DoIt  : True

## Status
ops-workflow       → drafts= 1, sendt= 0
turplan-camino     → drafts= 0, sendt= 0
dev-platform       → drafts= 0, sendt= 0
product-roadmap    → drafts= 0, sendt= 0
pilot-studier      → drafts= 5, sendt= 0
forskning-studier  → drafts= 5, sendt= 0
partner-tilskudd   → drafts= 5, sendt= 0
ideer-lab          → drafts= 5, sendt= 0
