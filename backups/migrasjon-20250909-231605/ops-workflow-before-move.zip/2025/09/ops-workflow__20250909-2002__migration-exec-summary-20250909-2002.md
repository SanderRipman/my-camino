# Migrasjonsrydd (UTFØR) — sammendrag

Kjørt : 2025-09-09 20:02:52
Root  : C:\Dev\my-camino
DoIt  : True

## Per ChatKey
ops-workflow       → flyttet    0  backup=C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250909-2002.zip
turplan-camino     → flyttet    0  backup=C:\Dev\my-camino\handover\backups\turplan-camino-captures-backup-20250909-2002.zip
dev-platform       → flyttet    0  backup=C:\Dev\my-camino\handover\backups\dev-platform-captures-backup-20250909-2002.zip
product-roadmap    → flyttet    0  backup=C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250909-2002.zip
pilot-studier      → flyttet    0  backup=C:\Dev\my-camino\handover\backups\pilot-studier-captures-backup-20250909-2002.zip
forskning-studier  → flyttet    0  backup=C:\Dev\my-camino\handover\backups\forskning-studier-captures-backup-20250909-2002.zip
partner-tilskudd   → flyttet    0  backup=C:\Dev\my-camino\handover\backups\partner-tilskudd-captures-backup-20250909-2002.zip
ideer-lab          → flyttet    0  backup=C:\Dev\my-camino\handover\backups\ideer-lab-captures-backup-20250909-2002.zip

## Videre
- Verifiser at AidMe-Index.md kun peker til siste ZIP pr ChatKey.
- Kjør helse-sjekk (counts + 5 siste filer pr ChatKey) ved behov.
