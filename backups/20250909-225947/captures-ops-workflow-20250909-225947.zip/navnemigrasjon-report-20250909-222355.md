# Navnestandard + migrasjonsrydd – 09/09/2025 22:24:03

| ChatKey | autosplit | last autosplit | zip |
|---|---:|:---|:---|
| ops-workflow | 15 | 09.09.2025 22:19:00 | C:\Dev\my-camino\handover\ops-workflow-handover.zip |
| dev-platform | 0 |  | C:\Dev\my-camino\handover\dev-platform-handover.zip |
| product-roadmap | 0 |  | C:\Dev\my-camino\handover\product-roadmap-handover.zip |
| turplan-camino | 0 |  | C:\Dev\my-camino\handover\turplan-camino-handover.zip |
| pilot-studier | 413 | 07.09.2025 13:48:25 | C:\Dev\my-camino\handover\pilot-studier-handover.zip |
| forskning-studier | 108 | 07.09.2025 13:48:29 | C:\Dev\my-camino\handover\forskning-studier-handover.zip |
| partner-tilskudd | 164 | 07.09.2025 13:48:30 | C:\Dev\my-camino\handover\partner-tilskudd-handover.zip |
| ideer-lab | 12 | 07.09.2025 13:48:32 | C:\Dev\my-camino\handover\ideer-lab-handover.zip |
