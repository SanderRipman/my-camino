# Utkast-generator — sammendrag
Kjørt : 2025-09-09 21:00:39
Root  : C:\Dev\my-camino
DoIt  : True

## Status
ops-workflow       → drafts= 1, forsøkt sendt= 1
turplan-camino     → drafts= 0, forsøkt sendt= 0
dev-platform       → drafts= 0, forsøkt sendt= 0
product-roadmap    → drafts= 0, forsøkt sendt= 0
pilot-studier      → drafts= 5, forsøkt sendt= 5
forskning-studier  → drafts= 5, forsøkt sendt= 5
partner-tilskudd   → drafts= 5, forsøkt sendt= 5
ideer-lab          → drafts= 5, forsøkt sendt= 5
