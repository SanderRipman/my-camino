# Migrasjonsrydd (UTFØR, rettet) — sammendrag

Kjørt : 2025-09-09 20:34:16
Root  : C:\Dev\my-camino
DoIt  : True

## Per ChatKey
ops-workflow       → flyttet    0  backup=C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250909-2034.zip
turplan-camino     → flyttet    0  backup=C:\Dev\my-camino\handover\backups\turplan-camino-captures-backup-20250909-2034.zip
dev-platform       → flyttet    0  backup=C:\Dev\my-camino\handover\backups\dev-platform-captures-backup-20250909-2034.zip
product-roadmap    → flyttet    0  backup=C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250909-2034.zip
pilot-studier      → flyttet    0  backup=C:\Dev\my-camino\handover\backups\pilot-studier-captures-backup-20250909-2034.zip
forskning-studier  → flyttet    0  backup=C:\Dev\my-camino\handover\backups\forskning-studier-captures-backup-20250909-2034.zip
partner-tilskudd   → flyttet    0  backup=C:\Dev\my-camino\handover\backups\partner-tilskudd-captures-backup-20250909-2034.zip
ideer-lab          → flyttet    0  backup=C:\Dev\my-camino\handover\backups\ideer-lab-captures-backup-20250909-2034.zip

## Videre
- Verifiser at AidMe-Index.md kun peker til siste ZIP pr ChatKey.
- Kjør helse-sjekk (counts + 5 siste filer pr ChatKey) ved behov.
