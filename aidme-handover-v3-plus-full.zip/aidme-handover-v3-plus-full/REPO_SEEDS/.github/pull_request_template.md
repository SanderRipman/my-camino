## Hva ble gjort
- [ ] Kort beskrivelse

## Sjekkliste
- [ ] Testet lokalt
- [ ] Netlify Deploy Preview grønn
