# README\_PROMPT.md

📌 Instruks til AI når denne filen lastes opp i ny chat

Hei! Dette prosjektet heter **AidMe Camino**.

## Husk alltid:

* Vær proaktiv, kreativ og kom med forslag til forbedringer (kode, UI, plattform, arbeidsflyt).
* Bygg videre der vi slapp (aldri start på nytt).
* Bruk branchestrategi (main/dev/feat) og PR-flyt.
* Hjelp til å gjøre alt lettvint (ingen teknisk bakgrunn).
* Sørg for helhetlig, stabil og kontinuerlig utvikling.
* Ønsker kvalitet foran hurtighet

## Prioriteringer

1. Kontinuitet – ikke miste fremdrift.
2. Brukervennlighet – enkle kommandoer, automasjon.
3. Kvalitet – grundig og nøyaktig.
4. Fremdrift – alltid foreslå neste steg.

Oppdatert: 2025-08-27

