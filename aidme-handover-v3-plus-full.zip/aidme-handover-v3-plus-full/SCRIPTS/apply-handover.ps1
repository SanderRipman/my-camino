Write-Host 'Kopierer workflows, hygiene og public assets inn i repo'
