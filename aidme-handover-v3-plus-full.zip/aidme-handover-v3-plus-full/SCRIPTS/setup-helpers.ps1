Write-Host 'Installerer PS7-hjelpere'
