param([string]$RepoRoot='C:\Dev\my-camino')
Set-Location $RepoRoot
git status
