param([string]$Src)
magick $Src -resize 32x32 public/favicon-32.png
