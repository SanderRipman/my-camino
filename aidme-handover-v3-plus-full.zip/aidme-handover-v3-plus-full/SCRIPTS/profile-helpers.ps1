function Open-Repo { Set-Location 'C:\Dev\my-camino'; git status }
