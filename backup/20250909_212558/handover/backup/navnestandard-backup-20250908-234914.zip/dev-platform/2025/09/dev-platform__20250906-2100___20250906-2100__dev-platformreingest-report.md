# Re-ingest dry-run — dev-platform  (20250906-2100)

Source ZIP : C:\Dev\my-camino\handover\dev-platform-v1-handover.zip
Candidates : 1
New        : 1
Existing   : 0

Examples (max 10):
- NEW  -> C

## Execute summary

Created : 0
ZipOut  : C:\Dev\my-camino\handover\dev-platform-handover.zip

Latest 10:
C:\Dev\my-camino\handover\captures\dev-platform\reingest-report-20250906-2100.md
C:\Dev\my-camino\handover\captures\dev-platform\dev-platform-reingest-report-20250906-2056.md
C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250906-163343-ops-forespørsel-kapasitet.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-131257.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-131124.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-125224.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-125156.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-123947.md
C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-122838.md
C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250905-131718-ops-forespørsel-kapasitet.md
