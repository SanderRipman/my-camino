# Navnestandard – verifisering (20250906-2130)

Root: C:\Dev\my-camino

## ops-workflow
Telling (standardnavn): **1674**
Siste 5:
