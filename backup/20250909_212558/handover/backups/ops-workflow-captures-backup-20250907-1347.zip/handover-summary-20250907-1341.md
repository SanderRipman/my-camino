# Handover – navnestandard/migrasjonsrydd – 20250907-1341

Root: C:\Dev\my-camino
Totalt planlagt flyttinger: 3420
Totalt gjennomført:         0
Totalt duplikater:          0

## Per ChatKey
* ops-workflow: DRY-RUN FERDIG (plan=12, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\ops-workflow\navnestandard-ops-workflow-20250907-1341.md
* dev-platform: DRY-RUN FERDIG (plan=35, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\dev-platform\navnestandard-dev-platform-20250907-1341.md
* product-roadmap: DRY-RUN FERDIG (plan=153, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\product-roadmap\navnestandard-product-roadmap-20250907-1341.md
* turplan-camino: DRY-RUN FERDIG (plan=2531, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\turplan-camino\navnestandard-turplan-camino-20250907-1341.md
* pilot-studier: DRY-RUN FERDIG (plan=411, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\pilot-studier\navnestandard-pilot-studier-20250907-1341.md
* forskning-studier: DRY-RUN FERDIG (plan=106, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\forskning-studier\navnestandard-forskning-studier-20250907-1341.md
* partner-tilskudd: DRY-RUN FERDIG (plan=162, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\partner-tilskudd\navnestandard-partner-tilskudd-20250907-1341.md
* ideer-lab: DRY-RUN FERDIG (plan=10, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\ideer-lab\navnestandard-ideer-lab-20250907-1341.md
