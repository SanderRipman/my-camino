# Navnestandard + migrasjonsrydd (UTFØR) – 20250909-1742

| ChatKey | Flyttet | Skippet | Standard-navn | Backup |
|---|---:|---:|---:|---|
