# ops-workflow
 - kandidater: 2
   backup: C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250909-1642.zip
   move: C:\Dev\my-camino\handover\captures\ops-workflow\navnestandard-migrasjonsrydd-report-20250909-1633.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250909-1633__navnestandard-migrasjonsrydd-report-20250909-1633.md
   move* (duplikat beholdt): C:\Dev\my-camino\handover\captures\ops-workflow\onepass-exec-20250909-1619.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250909-1619__onepass-exec-20250909-1619__dup.md
 - flyttet/renamet: 2
# dev-platform
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\dev-platform-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# product-roadmap
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# turplan-camino
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\turplan-camino-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# forskning-studier
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\forskning-studier-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# partner-tilskudd
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\partner-tilskudd-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# pilot-studier
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\pilot-studier-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
# ideer-lab
 - kandidater: 0
   backup: C:\Dev\my-camino\handover\backups\ideer-lab-captures-backup-20250909-1642.zip
 - flyttet/renamet: 0
