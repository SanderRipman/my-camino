## Navnestandard – UTFØR (20250908-234914)

Backup: C:\Dev\my-camino\handover\backup\navnestandard-backup-20250908-234914.zip

- partner-tilskudd: flyttet 164 filer
- turplan-camino: flyttet 2536 filer
- product-roadmap: flyttet 158 filer
- ideer-lab: flyttet 12 filer
- dev-platform: flyttet 40 filer
- forskning-studier: flyttet 108 filer
- pilot-studier: flyttet 413 filer
- ops-workflow: flyttet 23 filer
