# Navnestandard – ops-workflow (20250907-1341)

Root: C:\Dev\my-camino
Scope: handover/captures/ops-workflow

## Oppsummering
Filer funnet:               12
Kandidater (flytt/rename):  12
Duplikater (hopper over):   0
Planlagt å flytte:          12

## Planlagte endringer
- handover-summary-20250906-2304.md  ->  ops-workflow\2025\09\ops-workflow__20250906-2305__handover-summary-20250906-2304.md
- handover-summary-20250907-1248.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1248__handover-summary-20250907-1248.md
- handover-summary-20250907-1326.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1326__handover-summary-20250907-1326.md
- handover-summary-20250907-1332.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1332__handover-summary-20250907-1332.md
- migration-done-20250907-1237.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1238__migration-done-20250907-1237.md
- migration-done-20250907-1241.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1241__migration-done-20250907-1241.md
- migration-done-20250907-1243.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1243__migration-done-20250907-1243.md
- migration-dryrun-20250906-2304.md  ->  ops-workflow\2025\09\ops-workflow__20250906-2304__migration-dryrun-20250906-2304.md
- navnestandard-migrasjonsdryrun-20250907-1222.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1222__navnestandard-migrasjonsdryrun-20250907-1222.md
- snapshot-index-report-20250907-1307.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1307__snapshot-index-report-20250907-1307.md
- reports-20250907-1247\migrasjonsrydd-dryrun-20250907-1247.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1247__migrasjonsrydd-dryrun-20250907-1247.md
- reports-20250907-1247\navnestandard-dryrun-20250907-1247.md  ->  ops-workflow\2025\09\ops-workflow__20250907-1247__navnestandard-dryrun-20250907-1247.md
