# Handover summary (20250906-2304)

## Flyttinger
Totalt flyttet: 5092
Konflikter ved dry-run: 0

## Etter snapshot/index
- ops-workflow: autosplit=0
- turplan-camino: autosplit=0
- dev-platform: autosplit=0
- product-roadmap: autosplit=0
- pilot-studier: autosplit=0
- forskning-studier: autosplit=0
- partner-tilskudd: autosplit=0
- ideer-lab: autosplit=0


## Backup-arkiver
- C:\Dev\my-camino\handover\backup-ops-workflow-captures-20250906-2304.zip
- C:\Dev\my-camino\handover\backup-AidMe-Index-20250906-2304.zip

