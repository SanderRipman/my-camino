# Migration summary (20250909-1104)
Backup: C:\Dev\my-camino\handover\backup\captures-backup-20250909-1104.zip
Dry-run : C:\Dev\my-camino\handover\captures\ops-workflow\migration-dryrun-20250909-1104.md
Flyttet : 11
