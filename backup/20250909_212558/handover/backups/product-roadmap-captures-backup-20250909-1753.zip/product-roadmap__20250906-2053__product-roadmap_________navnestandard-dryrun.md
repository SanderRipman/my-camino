# Dry-run — product-roadmap (20250906-2253)

Kandidater totalt : 2
Konflikter        : 0
Allerede standard : 148

## Eksempler (inntil 20)
MOVE: C:\Dev\my-camino\handover\captures\product-roadmap\autosplit-20250905-125207-01.md
  ->  C:\Dev\my-camino\handover\captures\product-roadmap\2025\09\product-roadmap__20250905-1252__07-01.md
MOVE: C:\Dev\my-camino\handover\captures\product-roadmap\ops-reply-20250906-163343-ops-sync-roadmap-dev.md
  ->  C:\Dev\my-camino\handover\captures\product-roadmap\2025\09\product-roadmap__20250906-1337__ops-reply-43-ops-sync-roadmap-dev.md
