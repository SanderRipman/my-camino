# Migrasjonskjøring (20250909-1712)

* ops-workflow: backup → C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250909-1712.zip
  - snapshot OK (ops-workflow)
  - index → C:\Dev\my-camino\handover\ops-workflow-handover.zip
  - flyttet: 3, hoppet: 0

* dev-platform: backup → C:\Dev\my-camino\handover\backups\dev-platform-captures-backup-20250909-1712.zip
  - snapshot OK (dev-platform)
  - index → C:\Dev\my-camino\handover\dev-platform-handover.zip
  - flyttet: 0, hoppet: 0

* product-roadmap: backup → C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250909-1712.zip
  - snapshot OK (product-roadmap)
  - index → C:\Dev\my-camino\handover\product-roadmap-handover.zip
  - flyttet: 0, hoppet: 0

* turplan-camino: backup → C:\Dev\my-camino\handover\backups\turplan-camino-captures-backup-20250909-1712.zip
  - snapshot OK (turplan-camino)
  - index → C:\Dev\my-camino\handover\turplan-camino-handover.zip
  - flyttet: 0, hoppet: 0

