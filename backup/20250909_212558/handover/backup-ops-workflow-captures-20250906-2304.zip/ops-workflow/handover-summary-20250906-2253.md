# Handover summary — 2025-09-06 22:53
ops-workflow         1683 filer i standard
dev-platform           32 filer i standard
product-roadmap       150 filer i standard
pilot-studier         409 filer i standard
forskning-studier     104 filer i standard
partner-tilskudd      160 filer i standard
turplan-camino       2528 filer i standard
ideer-lab               8 filer i standard
