## Ops → product-roadmap : synk m/ dev-platform

**Status:** Dev bekrefter snart kapasitet for 1–2 småinnspill fra *ideer-lab*.  
**Foreslår:** Merk disse som Ready for Dev hvis kriterier er ok, og legg inn tentativt sprint-slot.

**Husk:** Hold pilot-studier informert hvis noe berører pågående pilotmål.
