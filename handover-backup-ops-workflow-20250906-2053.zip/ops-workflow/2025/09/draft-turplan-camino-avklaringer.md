## Ops → turplan-camino : synk m/ partner-tilskudd

**Spørsmål:** Har siste reiseplan-endringer noen påvirkning på milepæler eller innsendinger i *partner-tilskudd*?  
**Hvis ja:** Notér endringsdatoer og hva som flyttes, så sikrer vi dokument- og tidslinjeoppdatering.

**Next:** Send korte bullets tilbake.
