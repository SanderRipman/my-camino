# Handover summary (ops-workflow)
- Dry-run: C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-migration-dryrun-20250906-203036.md
- Migration report: C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-migration-report-20250906-203036.md
- Backup zip: C:\Dev\my-camino\handover\_migration-backups\ops-captures-20250906-203150.zip
- Index: C:\Dev\my-camino\AidMe-Index.md
- ZIP: C:\Dev\my-camino\handover\ops-workflow-handover.zip
