# Migration dry-run (20250906-2005)
ChatKey : ops-workflow
Root    : C:\Dev\my-camino

Planlagte flytt/rename: 1672
Duplikatfiler (vil fjernes): 1651

Eksempler (første 10):
* C:\Dev\my-camino\handover\captures\ops-workflow\outbox-dispatch-20250906-185403.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\outbox-dispatch-20250906-185403.md
* C:\Dev\my-camino\handover\captures\ops-workflow\outbox-dispatch-20250906-2004.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\outbox-dispatch-20250906-2004.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153433.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153433.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153434.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153434.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153435.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153435.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153436.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153436.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153437.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153437.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153438.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153438.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153439.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153439.md
* C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow__20250904-1534__ops-workflow-20250904-1534-note-153440.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153440.md
