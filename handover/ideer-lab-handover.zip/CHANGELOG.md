## test (2025-08-29)
- test

## vX.Y.Z (2025-08-26)
- notat

## vX.Y.Z (2025-08-26)
- kort notat

## v5.6.3 (2025-08-26)
- ny STT-fiks og UI-forbedringer

## vX.Y.Z (2025-08-26)
- kort notat

## v5.6.2 (2025-08-26)
- hotfix STT mobil + små UI-forbedringer

# Endringer

## v5.6.1
- Baseline (mest komplette): grafer, skjema, dagbok/etapper, motivasjon, profiler, varsler, import/eksport, NAV-kort, logo.
- Tale-til-tekst (STT) desktop fungerer stabilt.






