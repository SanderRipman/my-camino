# Auto-load public functions (dot-source)
Get-ChildItem $(Join-Path $PSScriptRoot 'Public\*.ps1') | ForEach-Object { . $_.FullName }
