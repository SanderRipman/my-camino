function Pause-Aid { param([string]$Message="(Enter for meny)"); Read-Host $Message | Out-Null }
