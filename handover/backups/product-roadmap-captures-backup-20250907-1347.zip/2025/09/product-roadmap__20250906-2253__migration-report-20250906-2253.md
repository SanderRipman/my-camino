# Migrasjonsrapport — product-roadmap (20250906-2253)

Dry-run kandidater : 2
Konflikter         : 0
Flyttet/renamet    : 2
Backup             : C:\Dev\my-camino\handover\backups\product-roadmap-captures-backup-20250906-2253.zip
Dry-run logg       : C:\Dev\my-camino\handover\captures\product-roadmap\dry-run\navnestandard-dryrun-20250906-2253.md
