# Fase 1 — migrasjonsrydd for ops-workflow (20250906-2053)
* Backup: C:\Dev\my-camino\handover-backup-ops-workflow-20250906-2053.zip
* Flyttet/renamet: 1674  (opprettet mapper: 0)
* Index oppdatert: ja
* Snapshot kjørt: ja

## Endringer (første 20)
* migration-dryrun-20250906-2005.md → 2025\09\ops-workflow__20250906-2005__Migration-dry-run-20250906-2005.md
* 2025\09\autosplit-20250905-125204-01.md → 2025\09\ops-workflow__20250905-1252__Startmelding-ops-workflow.md
* 2025\09\dev-platform-startmelding.md → 2025\09\ops-workflow__20250906-2032__Startmelding-dev-platform.md
* 2025\09\draft-product-roadmap-sync.md → 2025\09\ops-workflow__20250906-2032__Ops-product-roadmap-synk-m-dev-platform.md
* 2025\09\draft-turplan-camino-avklaringer.md → 2025\09\ops-workflow__20250906-2032__Ops-turplan-camino-synk-m-partner-tilskudd.md
* 2025\09\forskning-studier-startmelding.md → 2025\09\ops-workflow__20250906-2032__Startmelding-forskning-studier.md
* 2025\09\handover-summary-20250905-1329.md → 2025\09\ops-workflow__20250905-1329__Handover-ops-workflow-20250905-1329.md
* 2025\09\handover-summary-20250906-203036.md → 2025\09\ops-workflow__20250906-2030__Handover-summary-ops-workflow.md
* 2025\09\ideer-lab-startmelding.md → 2025\09\ops-workflow__20250906-2032__Startmelding-ideer-lab.md
* 2025\09\netlify-env-verify-20250906-0718.md → 2025\09\ops-workflow__20250906-0718__Netlify-env-verify-20250906-0718.md
* 2025\09\ops-hydration-20250906-132734.md → 2025\09\ops-workflow__20250906-1327__Ops-workflow-Hydration-20250906-132734.md
* 2025\09\ops-hydration-20250906-133736.md → 2025\09\ops-workflow__20250906-1337__ops-hydration-20250906-133736.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153433.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153433.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153434.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153434.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153435.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153435.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153436.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153436.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153437.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153437.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153438.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153438.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153439.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153439.md
* 2025\09\ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153440.md → 2025\09\ops-workflow__20250904-1534__ops-workflow-20250904-1534-ops-workflow-20250904-1534-ops-workflow-20250904-1534-note-153440.md
