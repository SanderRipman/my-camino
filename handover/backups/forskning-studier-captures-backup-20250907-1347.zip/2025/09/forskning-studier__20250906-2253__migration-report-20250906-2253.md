# Migrasjonsrapport — forskning-studier (20250906-2253)

Dry-run kandidater : 1
Konflikter         : 0
Flyttet/renamet    : 1
Backup             : C:\Dev\my-camino\handover\backups\forskning-studier-captures-backup-20250906-2253.zip
Dry-run logg       : C:\Dev\my-camino\handover\captures\forskning-studier\dry-run\navnestandard-dryrun-20250906-2253.md
