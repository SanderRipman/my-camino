## Ops → product-roadmap : synk m/ dev-platform
- Foreslå 2–3 kandidater fra *ideer-lab* som kan merkes **Ready for Dev**.
- Koble hver kandidat til milepæl/epic + tentativ sprint-slot.
