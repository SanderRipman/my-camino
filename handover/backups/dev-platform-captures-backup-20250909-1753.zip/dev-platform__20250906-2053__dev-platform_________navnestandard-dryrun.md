# Dry-run — dev-platform (20250906-2253)

Kandidater totalt : 18
Konflikter        : 0
Allerede standard : 15

## Eksempler (inntil 20)
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\autosplit-20250905-125159-01.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250905-1251__59-01.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-122838.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1228__continuity-report-38.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-123947.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1239__continuity-report-47.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-125156.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1251__continuity-report-56.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-125224.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1252__continuity-report-24.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-131124.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1311__continuity-report-24.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\continuity-report-20250906-131257.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1312__continuity-report-57.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\dev-platform__20250902-0904__readme.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250902-0904__readme.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\dev-platform-reingest-report-20250906-2056.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2056__reingest-report.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250905-131116-test.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250905-1311__ops-reply-16-test.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250905-131606-test.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250905-1316__ops-reply-06-test.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250905-131718-ops-forespørsel-kapasitet.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250905-1316__ops-reply-18-ops-forespørsel-kapasitet.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\ops-reply-20250906-163343-ops-forespørsel-kapasitet.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-1337__ops-reply-43-ops-forespørsel-kapasitet.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\reingest-report-20250906-2100.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2100__reingest-report.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\reingest-report-20250906-2110.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2110__reingest-report.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\reingest-report-20250906-212350.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2123__reingest-report-50.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\reinnhenting-report-20250906-2113.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2113__reinnhenting-report.md
MOVE: C:\Dev\my-camino\handover\captures\dev-platform\reinnhenting-report-20250906-2117.md
  ->  C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250906-2117__reinnhenting-report.md
