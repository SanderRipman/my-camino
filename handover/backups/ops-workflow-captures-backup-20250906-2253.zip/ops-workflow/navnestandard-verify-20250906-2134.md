# Navnestandard – verifisering (20250906-2134)

Root: C:\Dev\my-camino

## ops-workflow
Telling (standardnavn): **1674**
Siste 5:
  - handover\captures\ops-workflow\2025\09\ops-workflow__20250906-2030__Handover-summary-ops-workflow.md
  - handover\captures\ops-workflow\2025\09\ops-workflow__20250906-2005__Migration-dry-run-20250906-2005.md
  - handover\captures\ops-workflow\2025\09\ops-workflow__20250906-2032__Til-turplan-camino.md
  - handover\captures\ops-workflow\2025\09\ops-workflow__20250906-2032__Startmelding-turplan-camino.md
  - handover\captures\ops-workflow\2025\09\ops-workflow__20250906-2032__Startmelding-pilot-studier.md
ZIP-status: index→ZIP=OK

## dev-platform
Telling (standardnavn): **15**
Siste 5:
  - handover\captures\dev-platform\2025\09\dev-platform__20250905-0002__dev-platform-20250905-0002-note-000210-13.md
  - handover\captures\dev-platform\2025\09\dev-platform__20250905-0002__dev-platform-20250905-0002-note-000210-12.md
  - handover\captures\dev-platform\2025\09\dev-platform__20250905-0002__dev-platform-20250905-0002-note-000210-11.md
  - handover\captures\dev-platform\2025\09\dev-platform__20250905-0002__dev-platform-20250905-0002-note-000210-10.md
  - handover\captures\dev-platform\2025\09\dev-platform__20250905-0002__dev-platform-20250905-0002-note-000210-09.md
ZIP-status: index→ZIP=OK

