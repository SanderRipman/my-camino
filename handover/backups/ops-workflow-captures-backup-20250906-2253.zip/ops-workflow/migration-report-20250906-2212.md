# Migrasjonsrapport — ops-workflow (20250906-2212)

Dry-run kandidater : 1678
Konflikter         : 0
Flyttet/renamet    : 0
Backup             : C:\Dev\my-camino\handover\backups\ops-workflow-captures-backup-20250906-2212.zip
Dry-run logg       : 
