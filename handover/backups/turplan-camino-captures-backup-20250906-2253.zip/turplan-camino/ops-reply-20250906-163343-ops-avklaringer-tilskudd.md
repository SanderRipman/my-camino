## Ops → turplan-camino : påvirkning på partner-tilskudd
- Har siste reiseplan-endringer konsekvens for frister/innsendelser i *partner-tilskudd*?
- Hvis ja, noter hva som flyttes og forslag til oppdatert tidslinje.
