# Handover – navnestandard/migrasjonsrydd – 20250907-1347

Root: C:\Dev\my-camino
Totalt planlagt flyttinger: 3429
Totalt gjennomført:         3429
Totalt duplikater:          0

## Per ChatKey
* ops-workflow: APPLIED (flyttet=14, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\ops-workflow\navnestandard-ops-workflow-20250907-1347.md
* dev-platform: APPLIED (flyttet=36, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\dev-platform\navnestandard-dev-platform-20250907-1347.md
* product-roadmap: APPLIED (flyttet=154, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\product-roadmap\navnestandard-product-roadmap-20250907-1347.md
* turplan-camino: APPLIED (flyttet=2532, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\turplan-camino\navnestandard-turplan-camino-20250907-1347.md
* pilot-studier: APPLIED (flyttet=412, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\pilot-studier\navnestandard-pilot-studier-20250907-1347.md
* forskning-studier: APPLIED (flyttet=107, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\forskning-studier\navnestandard-forskning-studier-20250907-1347.md
* partner-tilskudd: APPLIED (flyttet=163, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\partner-tilskudd\navnestandard-partner-tilskudd-20250907-1347.md
* ideer-lab: APPLIED (flyttet=11, duplikater=0). Rapport: C:\Dev\my-camino\handover\captures\ideer-lab\navnestandard-ideer-lab-20250907-1347.md
