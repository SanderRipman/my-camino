# ops-workflow
 - kandidater: 1
   DRY: C:\Dev\my-camino\handover\captures\ops-workflow\onepass-exec-20250909-1619.md -> C:\Dev\my-camino\handover\captures\ops-workflow\2025\09\ops-workflow__20250909-1619__onepass-exec-20250909-1619.md
# dev-platform
 - kandidater: 0
# product-roadmap
 - kandidater: 0
# turplan-camino
 - kandidater: 0
