# Trygg re-innhenting — dev-platform
Dato: 20250906-2117
Kandidater funnet i ZIP  : 1
Opprettet (nye)          : 0
Allerede fantes          : 1



Totalt filer i captures/dev-platform etterpå: 29
