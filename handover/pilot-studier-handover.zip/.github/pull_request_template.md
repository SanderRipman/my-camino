\## Hva endres?

Kort beskrivelse av hva som er gjort.



\## Hvorfor?

Beskriv formålet/nytten.



\## Sjekkliste før merge

\- \[ ] Koden bygger lokalt (om aktuelt)

\- \[ ] Netlify \*\*Deploy Preview\*\* er grønn

\- \[ ] Funksjonen testet på \*\*Preview-URL\*\*

\- \[ ] (Om relevant) Oppdatert `README.md`

\- \[ ] (Om relevant) Oppdatert `CHANGELOG.md`

\- \[ ] Ingen sensitive nøkler/hemmeligheter i koden



\## Hvordan teste

1\) Åpne PR → vent på Netlify-check → klikk \*\*Details\*\*  

2\) Test på Preview-URL  

3\) Sjekk konsoll (F12) for feil  

4\) Kryss av sjekklisten



