# Re-ingest dry-run — dev-platform  (20250906-2110)
Source ZIP : C:\Dev\my-camino\handover\dev-platform-v1-handover.zip
Candidates : 1
New        : 1
Existing   : 0
Invalid    : 0

Examples (max 10):
- NEW  -> C:\Dev\my-camino\handover\captures\dev-platform\2025\09\dev-platform__20250902-0904__readme.md


