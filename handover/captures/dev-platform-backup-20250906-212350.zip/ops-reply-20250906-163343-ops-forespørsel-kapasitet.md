## Ops → dev-platform : kort status og kapasitet
- Bekreft at dere ser siste autosplit (ref. hydration).
- Oppgi om dere har kapasitet til 1–2 små oppgaver fra *ideer-lab* denne uken.
- List ev. avhengigheter (data, design, beslutning).
